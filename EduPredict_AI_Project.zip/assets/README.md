# EduPredict AI - Assets Directory

This folder contains static styling, UI theme configurations, and media resources for the EduPredict AI Streamlit dashboard.

- `style.css`: Custom CSS styling for metric cards, responsive hero banners, recommendation cards, and custom status pills.

