"""
EduPredict AI — Page 4: Student Records & Batch CSV Processing
Interactive record exploration, multi-criteria filtering,
dataset export, and batch machine learning inference for external CSV files.
"""

import os
import sys
import streamlit as st
import pandas as pd
import numpy as np

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from src.data_preprocessing import load_data, CATEGORY_ORDER, FEATURE_COLUMNS, validate_dataframe
from src.predict import get_predictor

st.set_page_config(
    page_title="Student Records — EduPredict AI",
    page_icon="📋",
    layout="wide"
)

# Custom CSS
css_path = os.path.join(BASE_DIR, "assets", "style.css")
if os.path.exists(css_path):
    with open(css_path, "r") as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

@st.cache_data
def get_records_data():
    data_path = os.path.join(BASE_DIR, "data", "student_performance.csv")
    return load_data(data_path)

@st.cache_data
def get_sample_template():
    template_path = os.path.join(BASE_DIR, "data", "sample_input_template.csv")
    if os.path.exists(template_path):
        return pd.read_csv(template_path)
    return None

def main():
    st.markdown("## 📋 Student Records Management & Batch AI Inference")
    st.markdown(
        "Inspect institutional student records, filter by academic categories, "
        "download existing datasets, or upload a new cohort CSV to generate automated batch predictions."
    )
    st.markdown("---")

    df = get_records_data()
    predictor = get_predictor()

    tab1, tab2 = st.tabs(["📚 Institutional Student Directory", "📤 Batch CSV Upload & Inference"])

    # ---------------------------------------------------------
    # TAB 1: Student Directory & Search
    # ---------------------------------------------------------
    with tab1:
        st.markdown("### 🔍 Search & Filter Student Records")
        
        c1, c2, c3 = st.columns([1.5, 1, 1])
        with c1:
            search_query = st.text_input("🔎 Search by Student ID:", placeholder="e.g. STD-1025, STD-1100...")
        with c2:
            cat_filter = st.multiselect(
                "Filter by Category:",
                options=CATEGORY_ORDER,
                default=CATEGORY_ORDER
            )
        with c3:
            support_only = st.checkbox("Show Only Students Needing Support (Marks < 50)")

        # Filtering logic
        view_df = df.copy()
        if search_query.strip():
            view_df = view_df[view_df['student_id'].astype(str).str.contains(search_query.strip(), case=False, na=False)]
        if cat_filter:
            view_df = view_df[view_df['performance_category'].isin(cat_filter)]
        if support_only:
            view_df = view_df[view_df['final_marks'] < 50.0]

        st.caption(f"Displaying **{len(view_df):,}** of **{len(df):,}** student records.")

        # Display table
        st.dataframe(
            view_df.style.format({
                'previous_marks': '{:.1f}',
                'study_hours_per_day': '{:.1f} hrs',
                'attendance_percentage': '{:.1f}%',
                'assignment_completion_rate': '{:.1f}%',
                'extracurricular_hours': '{:.1f} hrs',
                'final_marks': '{:.1f}'
            }),
            use_container_width=True,
            height=420
        )

        st.markdown("<br>", unsafe_allow_html=True)
        st.markdown("### 📥 Download Institutional Data")
        d_col1, d_col2 = st.columns(2)
        
        with d_col1:
            csv_data = df.to_csv(index=False).encode('utf-8')
            st.download_button(
                label="📥 Download Full Institutional Dataset (CSV)",
                data=csv_data,
                file_name="edupredict_student_dataset.csv",
                mime="text/csv",
                use_container_width=True
            )
            
        with d_col2:
            sample_df = get_sample_template()
            if sample_df is not None:
                sample_csv = sample_df.to_csv(index=False).encode('utf-8')
                st.download_button(
                    label="📥 Download Blank Template for Batch Prediction (CSV)",
                    data=sample_csv,
                    file_name="sample_student_input_template.csv",
                    mime="text/csv",
                    use_container_width=True
                )

    # ---------------------------------------------------------
    # TAB 2: Batch Upload & Inference
    # ---------------------------------------------------------
    with tab2:
        st.markdown("### 📤 Upload Cohort CSV for Batch Prediction")
        st.markdown(
            "Upload an external CSV file containing student behavioral and academic indicators. "
            "EduPredict AI will validate each column, process features through the preprocessing pipeline, "
            "and append **Predicted Final Marks**, **Predicted Category**, and **Academic Risk Level**."
        )

        st.info(
            f"**Required CSV Column Headers:** `{', '.join(FEATURE_COLUMNS)}`\n\n"
            "*(Optional: `student_id` for identifying records)*"
        )

        uploaded_file = st.file_uploader(
            "Choose a CSV file to evaluate:",
            type=["csv"],
            help="Upload a standard CSV file up to 200MB."
        )

        if uploaded_file is not None:
            try:
                upload_df = pd.read_csv(uploaded_file)
                st.success(f"File uploaded successfully! Loaded **{len(upload_df)}** records.")
                st.markdown("#### 👁️ Raw Upload Preview (First 5 Rows)")
                st.dataframe(upload_df.head(), use_container_width=True)

                # Validate schema
                is_valid, v_msg = validate_dataframe(upload_df, require_targets=False)
                if not is_valid:
                    st.error(f"❌ CSV Validation Error: {v_msg}")
                    st.warning("Please download and review the sample template in the previous tab.")
                    return
                else:
                    st.success("✅ Column schema and numerical value range validation passed.")

                # Batch prediction button
                if st.button("🚀 Run Batch Machine Learning Inference", type="primary", use_container_width=True):
                    with st.spinner("Executing batch predictions across models..."):
                        pred_df = predictor.predict_batch(upload_df)

                    st.balloons()
                    st.success("🎉 Batch Prediction Completed Successfully!")

                    # Quick summary metrics of batch
                    b_col1, b_col2, b_col3 = st.columns(3)
                    with b_col1:
                        st.metric("Total Cohort Evaluated", len(pred_df))
                    with b_col2:
                        st.metric("Predicted Average Score", f"{pred_df['predicted_marks'].mean():.1f} / 100")
                    with b_col3:
                        at_risk_count = int(pred_df['needs_academic_support'].sum())
                        st.metric("Students Flagged for Support", at_risk_count, delta_color="inverse")

                    # Display results
                    st.markdown("#### 📊 Prediction Results Table")
                    st.dataframe(
                        pred_df.style.format({
                            'previous_marks': '{:.1f}',
                            'study_hours_per_day': '{:.1f}',
                            'attendance_percentage': '{:.1f}%',
                            'assignment_completion_rate': '{:.1f}%',
                            'predicted_marks': '{:.1f}'
                        }),
                        use_container_width=True,
                        height=400
                    )

                    # Export button
                    output_csv = pred_df.to_csv(index=False).encode('utf-8')
                    st.download_button(
                        label="📥 Download Annotated Predictions (CSV)",
                        data=output_csv,
                        file_name="edupredict_batch_predictions.csv",
                        mime="text/csv",
                        type="primary"
                    )

            except Exception as e:
                st.error(f"Error processing uploaded CSV file: {e}")

if __name__ == "__main__":
    main()

