"""
EduPredict AI — Page 1: Student Performance Prediction
Interactive single-student prediction interface using trained Scikit-learn models.
Provides marks estimation, category classification, visual gauge, factor analysis,
and personalized academic improvement guidance.
"""

import os
import sys
import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from src.predict import get_predictor

st.set_page_config(
    page_title="Student Prediction — EduPredict AI",
    page_icon="🔮",
    layout="wide"
)

# Custom CSS
css_path = os.path.join(BASE_DIR, "assets", "style.css")
if os.path.exists(css_path):
    with open(css_path, "r") as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

def render_gauge_chart(score: float, category: str):
    """Generates an aesthetic Plotly indicator gauge."""
    if score >= 80:
        bar_color = "#3B82F6"
    elif score >= 65:
        bar_color = "#10B981"
    elif score >= 40:
        bar_color = "#F59E0B"
    else:
        bar_color = "#EF4444"

    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=score,
        domain={'x': [0, 1], 'y': [0, 1]},
        title={'text': f"<b>{category}</b>", 'font': {'size': 20, 'color': bar_color}},
        number={'suffix': " / 100", 'font': {'size': 32, 'color': '#1E293B'}},
        gauge={
            'axis': {'range': [0, 100], 'tickwidth': 1, 'tickcolor': "#94A3B8"},
            'bar': {'color': bar_color, 'thickness': 0.3},
            'bgcolor': "white",
            'borderwidth': 2,
            'bordercolor': "#E2E8F0",
            'steps': [
                {'range': [0, 40], 'color': '#FEE2E2'},
                {'range': [40, 65], 'color': '#FEF3C7'},
                {'range': [65, 80], 'color': '#D1FAE5'},
                {'range': [80, 100], 'color': '#DBEAFE'}
            ],
            'threshold': {
                'line': {'color': "#1E3A8A", 'width': 3},
                'thickness': 0.8,
                'value': score
            }
        }
    ))
    fig.update_layout(
        height=260,
        margin=dict(l=25, r=25, t=35, b=25),
        paper_bgcolor='rgba(0,0,0,0)',
        font={'family': "Inter, sans-serif"}
    )
    return fig

def main():
    st.markdown("## 🔮 Individual Student Performance Prediction")
    st.markdown(
        "Enter academic records and behavioral factors below to generate an AI-powered "
        "final marks estimation, performance categorization, risk tier, and tailored improvement recommendations."
    )
    st.markdown("---")

    # Load trained predictor
    try:
        predictor = get_predictor()
    except Exception as e:
        st.error(f"❌ Could not load trained models: {e}. Please run `python -m src.train_model` first.")
        return

    # Two column input layout
    with st.form(key="prediction_form"):
        st.markdown("### 📝 Student Academic & Engagement Profile")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("#### 🎓 Academic Indicators")
            previous_marks = st.number_input(
                "Previous Examination Marks (0 - 100):",
                min_value=0.0,
                max_value=100.0,
                value=68.5,
                step=0.5,
                help="Marks scored in the preceding semester or qualification examination."
            )
            
            attendance_percentage = st.slider(
                "Attendance Percentage (%):",
                min_value=0.0,
                max_value=100.0,
                value=82.0,
                step=0.5,
                help="Classroom and laboratory attendance rate for the current term."
            )
            
            assignment_completion = st.slider(
                "Assignment Completion Rate (%):",
                min_value=0.0,
                max_value=100.0,
                value=85.0,
                step=1.0,
                help="Percentage of submitted homework, lab files, and continuous assessment tasks."
            )
            
            class_participation = st.selectbox(
                "Classroom Participation Level:",
                options=["High", "Medium", "Low"],
                index=1,
                help="Interactive engagement, discussion participation, and seminar presentations."
            )

        with col2:
            st.markdown("#### ⏱️ Study Habits & Environmental Factors")
            study_hours = st.slider(
                "Daily Self-Study Hours (hrs/day):",
                min_value=0.0,
                max_value=12.0,
                value=4.0,
                step=0.5,
                help="Average daily hours devoted to self-study outside regular college lectures."
            )
            
            extracurricular_hours = st.slider(
                "Extracurricular Hours per Week (hrs/week):",
                min_value=0.0,
                max_value=24.0,
                value=3.0,
                step=0.5,
                help="Time spent in athletics, student clubs, hackathons, or creative activities."
            )
            
            internet_access = st.radio(
                "High-Speed Internet Access at Residence:",
                options=["Yes", "No"],
                index=0,
                horizontal=True,
                help="Reliable internet connection available for online research, coding, and LMS access."
            )
            
            family_support = st.selectbox(
                "Family Educational Support:",
                options=["High", "Moderate", "Low"],
                index=0,
                help="Level of family encouragement, resource availability, and study environment at home."
            )
            
            parental_education = st.selectbox(
                "Parental Education Level:",
                options=["High School", "Bachelor", "Master", "Doctorate"],
                index=1,
                help="Highest education level achieved by parents."
            )

        st.markdown("<br>", unsafe_allow_html=True)
        submit_btn = st.form_submit_button(
            label="🎯 Predict Student Performance",
            use_container_width=True,
            type="primary"
        )

    # Process prediction upon form submission
    if submit_btn:
        # Input validation
        validation_errors = []
        if previous_marks < 0 or previous_marks > 100:
            validation_errors.append("Previous marks must be between 0 and 100.")
        if attendance_percentage < 0 or attendance_percentage > 100:
            validation_errors.append("Attendance must be between 0 and 100%.")
        if study_hours < 0 or study_hours > 24:
            validation_errors.append("Study hours must be between 0 and 24 hours/day.")
            
        if validation_errors:
            for err in validation_errors:
                st.error(f"Validation Error: {err}")
            return

        student_payload = {
            'previous_marks': float(previous_marks),
            'study_hours_per_day': float(study_hours),
            'attendance_percentage': float(attendance_percentage),
            'assignment_completion_rate': float(assignment_completion),
            'extracurricular_hours': float(extracurricular_hours),
            'internet_access': internet_access,
            'family_support': family_support,
            'class_participation': class_participation,
            'parental_education': parental_education
        }

        with st.spinner("Processing features through ML Pipeline & Generating Predictions..."):
            try:
                result = predictor.predict_single(student_payload)
            except Exception as e:
                st.error(f"Inference error: {e}")
                return

        st.success("✅ Prediction Successfully Generated by Trained Machine Learning Models!")
        
        # Display Prediction Cards
        res_col1, res_col2 = st.columns([1, 1.2])

        with res_col1:
            st.markdown("### 🏆 Predicted Academic Standing")
            gauge_fig = render_gauge_chart(result['predicted_marks'], result['predicted_category'])
            st.plotly_chart(gauge_fig, use_container_width=True)

            # Performance & Risk Badges
            risk_badge_color = result['risk_color']
            st.markdown(
                f"""
                <div style="background:{result['risk_color']}15; border:1px solid {result['risk_color']}; border-radius:10px; padding:12px 16px; margin-top:8px;">
                    <div style="font-size:0.85rem; font-weight:600; color:{result['risk_color']};">RISK EVALUATION STATUS</div>
                    <div style="font-size:1.15rem; font-weight:700; color:#1E293B;">{result['risk_level']}</div>
                    <div style="font-size:0.8rem; color:#475569; margin-top:4px;">
                        {'⚠️ Additional academic mentoring & remedial support recommended.' if result['support_needed'] else '✨ Student demonstrates strong academic momentum and consistency.'}
                    </div>
                </div>
                """,
                unsafe_allow_html=True
            )

        with res_col2:
            st.markdown("### 🔍 Model Confidence & Key Factors")
            
            # Category probability distribution bar
            if result.get('category_probabilities'):
                probs = result['category_probabilities']
                prob_df = pd.DataFrame({
                    'Category': list(probs.keys()),
                    'Confidence (%)': list(probs.values())
                })
                prob_fig = px.bar(
                    prob_df,
                    x='Confidence (%)',
                    y='Category',
                    orientation='h',
                    color='Category',
                    color_discrete_map={
                        'Needs Improvement': '#EF4444',
                        'Average': '#F59E0B',
                        'Good': '#10B981',
                        'Excellent': '#3B82F6'
                    },
                    text='Confidence (%)'
                )
                prob_fig.update_layout(
                    height=160,
                    margin=dict(l=10, r=10, t=10, b=10),
                    showlegend=False,
                    xaxis=dict(range=[0, 100])
                )
                st.plotly_chart(prob_fig, use_container_width=True)

            # Key contributing factors
            st.markdown("#### ⚡ Key Influencing Factors")
            factors = result.get('key_factors', [])
            if factors:
                for f in factors:
                    icon = "🟢" if "(+)" in f['impact'] else "🔴"
                    st.markdown(f"**{icon} {f['factor']}** ({f['impact']}): *{f['desc']}*")
            else:
                st.markdown("Balanced profile across baseline indicators.")

        st.markdown("---")

        # Personalized Study Recommendations Section
        st.markdown("### 💡 Personalized Study Recommendations")
        st.caption("Explainable academic guidance automatically generated from the student's specific behavioral inputs.")

        recs = result.get('recommendations', [])
        if recs:
            for rec in recs:
                card_class = f"rec-{rec['severity']}"
                st.markdown(
                    f"""
                    <div class="rec-card {card_class}">
                        <div style="display:flex; justify-content:space-between; align-items:center;">
                            <b>📌 {rec['title']}</b>
                            <span style="font-size:0.75rem; text-transform:uppercase; font-weight:600; color:#475569;">
                                {rec['category']}
                            </span>
                        </div>
                        <div style="font-size:0.9rem; margin-top:6px; color:#334155;">{rec['message']}</div>
                        <div style="font-size:0.85rem; margin-top:8px; color:#1E3A8A; font-weight:600;">
                            👉 Action Step: {rec['action_item']}
                        </div>
                    </div>
                    """,
                    unsafe_allow_html=True
                )

        # Transparent disclaimer
        st.markdown(
            """
            <div class="disclaimer-box">
                <b>ℹ️ Important Note:</b> Predictions are generated using trained Scikit-learn algorithms based on mathematical patterns in historical training data. They serve as guidance estimates to facilitate timely mentorship and do not constitute a guarantee of future exam marks.
            </div>
            """,
            unsafe_allow_html=True
        )

if __name__ == "__main__":
    main()

