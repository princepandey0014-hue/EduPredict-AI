"""
EduPredict AI — Page 2: Student Analytics & Exploratory Data Analysis
Comprehensive, interactive visual analytics for student performance data.
Features bivariate analysis, correlation matrix, category distribution,
and feature importance derived from trained machine learning models.
"""

import os
import sys
import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from src.data_preprocessing import load_data, CATEGORY_ORDER, NUMERICAL_FEATURES
from src.predict import get_predictor

st.set_page_config(
    page_title="Student Analytics — EduPredict AI",
    page_icon="📊",
    layout="wide"
)

# Custom CSS
css_path = os.path.join(BASE_DIR, "assets", "style.css")
if os.path.exists(css_path):
    with open(css_path, "r") as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

# Safe check for statsmodels (for OLS trendline rendering)
HAS_STATSMODELS = False
try:
    import statsmodels.api as sm
    HAS_STATSMODELS = True
except ImportError:
    pass

@st.cache_data
def get_analytics_data():
    data_path = os.path.join(BASE_DIR, "data", "student_performance.csv")
    return load_data(data_path)

def main():
    st.markdown("## 📊 Student Academic Analytics & Exploratory Insights")
    st.markdown(
        "Explore relationships between behavioral inputs, attendance, study habits, "
        "and final academic outcomes. Use the interactive filters on the left to analyze specific student cohorts."
    )
    st.markdown("---")

    df = get_analytics_data()
    predictor = get_predictor()

    # Sidebar Interactive Filters
    st.sidebar.markdown("### 🔍 Dataset Filters")
    
    selected_categories = st.sidebar.multiselect(
        "Performance Categories:",
        options=CATEGORY_ORDER,
        default=CATEGORY_ORDER
    )
    
    min_attendance, max_attendance = st.sidebar.slider(
        "Attendance Range (%):",
        min_value=float(df['attendance_percentage'].min()),
        max_value=100.0,
        value=(float(df['attendance_percentage'].min()), 100.0)
    )
    
    internet_filter = st.sidebar.multiselect(
        "Internet Availability:",
        options=df['internet_access'].unique().tolist(),
        default=df['internet_access'].unique().tolist()
    )
    
    support_filter = st.sidebar.multiselect(
        "Family Support Level:",
        options=df['family_support'].unique().tolist(),
        default=df['family_support'].unique().tolist()
    )
    
    # Filter dataset
    filtered_df = df[
        (df['performance_category'].isin(selected_categories)) &
        (df['attendance_percentage'] >= min_attendance) &
        (df['attendance_percentage'] <= max_attendance) &
        (df['internet_access'].isin(internet_filter)) &
        (df['family_support'].isin(support_filter))
    ]
    
    st.sidebar.markdown(f"**Filtered Cohort:** {len(filtered_df):,} of {len(df):,} students")

    if filtered_df.empty:
        st.warning("⚠️ No student records match the selected filter criteria. Please broaden your selection.")
        return

    # Color mapping
    color_map = {
        'Needs Improvement': '#EF4444',
        'Average': '#F59E0B',
        'Good': '#10B981',
        'Excellent': '#3B82F6'
    }

    # Row 1: Study Hours vs Final Marks & Attendance vs Final Marks
    r1_col1, r1_col2 = st.columns(2)

    with r1_col1:
        st.markdown("### ⏱️ Study Hours vs. Final Marks")
        fig_study = px.scatter(
            filtered_df,
            x="study_hours_per_day",
            y="final_marks",
            color="performance_category",
            color_discrete_map=color_map,
            category_orders={"performance_category": CATEGORY_ORDER},
            trendline="ols" if HAS_STATSMODELS else None,
            hover_data=["student_id", "previous_marks", "attendance_percentage"],
            labels={
                "study_hours_per_day": "Daily Self-Study (Hours/Day)",
                "final_marks": "Final Examination Marks"
            }
        )
        fig_study.update_layout(height=360, margin=dict(l=20, r=20, t=20, b=20))
        st.plotly_chart(fig_study, use_container_width=True)
        st.caption("Linear trendline illustrates positive return on daily self-study hours across all grade tiers.")

    with r1_col2:
        st.markdown("### 🏫 Attendance Percentage vs. Final Marks")
        fig_att = px.scatter(
            filtered_df,
            x="attendance_percentage",
            y="final_marks",
            color="performance_category",
            color_discrete_map=color_map,
            category_orders={"performance_category": CATEGORY_ORDER},
            trendline="ols" if HAS_STATSMODELS else None,
            hover_data=["student_id", "study_hours_per_day"],
            labels={
                "attendance_percentage": "Lecture Attendance Percentage (%)",
                "final_marks": "Final Examination Marks"
            }
        )
        fig_att.add_vline(x=75, line_dash="dash", line_color="#EF4444", annotation_text="75% Min. Threshold")
        fig_att.update_layout(height=360, margin=dict(l=20, r=20, t=20, b=20))
        st.plotly_chart(fig_att, use_container_width=True)
        st.caption("Attendance below the 75% dashed line is strongly correlated with students entering the 'Needs Improvement' cohort.")

    st.markdown("<br>", unsafe_allow_html=True)

    # Row 2: Assignment Completion & Previous vs Final Marks
    r2_col1, r2_col2 = st.columns(2)

    with r2_col1:
        st.markdown("### 📝 Assignment Completion vs. Final Marks")
        fig_assign = px.scatter(
            filtered_df,
            x="assignment_completion_rate",
            y="final_marks",
            color="class_participation",
            category_orders={"class_participation": ["Low", "Medium", "High"]},
            labels={
                "assignment_completion_rate": "Assignment Completion Rate (%)",
                "final_marks": "Final Examination Marks",
                "class_participation": "Class Participation"
            }
        )
        fig_assign.update_layout(height=360, margin=dict(l=20, r=20, t=20, b=20))
        st.plotly_chart(fig_assign, use_container_width=True)
        st.caption("High assignment completion paired with active classroom participation consistently elevates final standing.")

    with r2_col2:
        st.markdown("### 📈 Previous Marks vs. Final Marks")
        fig_prev = px.scatter(
            filtered_df,
            x="previous_marks",
            y="final_marks",
            color="performance_category",
            color_discrete_map=color_map,
            category_orders={"performance_category": CATEGORY_ORDER},
            labels={
                "previous_marks": "Previous Examination Marks",
                "final_marks": "Final Examination Marks"
            }
        )
        # Add equality line
        fig_prev.add_trace(
            go.Scatter(
                x=[20, 100], y=[20, 100],
                mode='lines',
                name='Baseline Consistency (y=x)',
                line=dict(color='#94A3B8', dash='dot')
            )
        )
        fig_prev.update_layout(height=360, margin=dict(l=20, r=20, t=20, b=20))
        st.plotly_chart(fig_prev, use_container_width=True)
        st.caption("Points above the dotted line denote students who improved upon their previous examination record.")

    st.markdown("<br>", unsafe_allow_html=True)

    # Row 3: Correlation Matrix & Feature Importance
    r3_col1, r3_col2 = st.columns(2)

    with r3_col1:
        st.markdown("### 🧬 Numerical Correlation Heatmap")
        corr_cols = NUMERICAL_FEATURES + ['final_marks']
        corr_matrix = filtered_df[corr_cols].corr().round(2)
        
        heatmap_fig = px.imshow(
            corr_matrix,
            text_auto=True,
            aspect="auto",
            color_continuous_scale="Blues",
            labels=dict(color="Correlation"),
            title="Pearson Correlation Coefficient Matrix"
        )
        heatmap_fig.update_layout(height=380, margin=dict(l=20, r=20, t=30, b=20))
        st.plotly_chart(heatmap_fig, use_container_width=True)
        st.caption("Previous marks, attendance, and study hours exhibit strongest positive linear correlation with final marks.")

    with r3_col2:
        st.markdown("### 🌲 Machine Learning Feature Importance")
        if predictor is not None and predictor.metrics and 'reg_importances' in predictor.metrics:
            importances = predictor.metrics['reg_importances']
            # Sort top 10 features
            sorted_imp = sorted(importances.items(), key=lambda x: x[1], reverse=True)[:10]
            imp_df = pd.DataFrame(sorted_imp, columns=['Feature', 'Importance Score'])
            
            imp_fig = px.bar(
                imp_df,
                x='Importance Score',
                y='Feature',
                orientation='h',
                color='Importance Score',
                color_continuous_scale='Viridis',
                title="Top 10 Feature Importances (Random Forest Regressor)"
            )
            imp_fig.update_layout(
                yaxis={'categoryorder': 'total ascending'},
                height=380,
                margin=dict(l=20, r=20, t=30, b=20)
            )
            st.plotly_chart(imp_fig, use_container_width=True)
            st.caption("Feature importances computed using Gini impurity reduction from the trained Random Forest Regressor.")
        else:
            st.info("Feature importance will be visualized after running `python -m src.train_model`.")

if __name__ == "__main__":
    main()

