"""
EduPredict AI — Page 5: About Project & MCA College Documentation
Project overview, technical architecture, methodology,
system limitations, ethical considerations, and developer credentials.
"""

import os
import sys
import streamlit as st

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

st.set_page_config(
    page_title="About Project — EduPredict AI",
    page_icon="ℹ️",
    layout="wide"
)

# Custom CSS
css_path = os.path.join(BASE_DIR, "assets", "style.css")
if os.path.exists(css_path):
    with open(css_path, "r") as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

def main():
    st.markdown("## ℹ️ About EduPredict AI — Project Overview & Documentation")
    st.markdown(
        "**Master of Computer Applications (MCA) Final Project** | "
        "Domain: Machine Learning, Educational Data Mining (EDM), & Applied Data Science."
    )
    st.markdown("---")

    col1, col2 = st.columns([2, 1.2])

    with col1:
        st.markdown("### 🎯 1. Aim & Objectives")
        st.markdown(
            """
            The primary objective of **EduPredict AI** is to design, develop, and evaluate an automated, 
            interpretable machine learning system capable of predicting student final examination outcomes 
            and categorizing academic performance tiers during the semester.
            
            **Key Core Objectives:**
            1. **Early Academic Risk Detection**: Flag struggling students early in the term before final semester exams.
            2. **Multi-Algorithm Evaluation**: Train and comparatively benchmark Linear Regression, Decision Trees, Random Forests, and Logistic Regression on unseen holdout test data.
            3. **Explainable AI (XAI) Recommendations**: Provide rule-based, transparent study advice rather than black-box guesses.
            4. **Production-Ready Web Application**: Implement a responsive, accessible dashboard with Streamlit, Plotly, and Joblib model caching.
            5. **Rigorous Data Preprocessing**: Prevent data leakage by isolating transformation parameters strictly to the training set.
            """
        )

        st.markdown("### 🛠️ 2. Technology Stack")
        st.markdown(
            """
            | Component | Technology | Version / Specification |
            | :--- | :--- | :--- |
            | **Programming Language** | Python | 3.11+ CPython |
            | **Web Application Framework** | Streamlit | Responsive Multi-Page Architecture |
            | **Machine Learning Core** | Scikit-Learn | Regressors, Classifiers, Pipelines |
            | **Data Manipulation** | Pandas & NumPy | Vectorized Preprocessing & Imputation |
            | **Data Visualization** | Plotly & Matplotlib | Interactive SVG/WebGL Visuals & Heatmaps |
            | **Model Serialization** | Joblib | Compressed Disk Persistence (`.joblib`) |
            | **Target Environment** | Windows 10/11 | VS Code, PowerShell, Virtual Environment |
            """
        )

        st.markdown("### 🔄 3. Machine Learning System Workflow")
        st.markdown(
            """
            ```
            [ Raw Student Data (CSV) ]
                       │
                       ▼
            [ Data Cleaning & Range Validation ]
                       │
                       ▼
            [ 80 / 20 Train-Test Stratified Split ] (random_state=42)
                       │
                       ├─────────────────────────────────┐
                       ▼                                 ▼
             [ Fit Preprocessor on Train ]    [ Transform Test Holdout ]
             (StandardScaler + OneHotEncoder)                 │
                       │                                      │
                       ▼                                      ▼
             [ Train ML Algorithms ]               [ Unseen Test Evaluation ]
             • Linear Regression                   • MAE, MSE, RMSE, R²
             • Decision Tree Regressor             • Accuracy, Precision, Recall
             • Random Forest Regressor             • F1-Score, Confusion Matrix
             • Logistic Regression                            │
                       │                                      ▼
                       └───────────────┬──────────────────────┘
                                       ▼
                       [ Persist Models with Joblib ]
                                       │
                                       ▼
                       [ Streamlit Production Dashboard ]
                       (Real-time Inference, Batch CSV, Recommendations)
            ```
            """
        )

        st.markdown("### ⚠️ 4. Ethical Considerations & System Limitations")
        st.markdown(
            """
            - **Non-Clinical Advisory**: EduPredict AI outputs are statistical educational estimates, not cognitive or psychological evaluations.
            - **Synthetic Benchmark Transparency**: The demonstrative dataset simulates realistic educational correlations based on domain literature. Synthetic results establish technical viability but do not replace localized institutional validation.
            - **Extenuating Circumstances**: Machine learning models evaluate historical academic indicators and cannot anticipate unforeseen life events, medical emergencies, or personal difficulties.
            - **Preventing Bias**: Educational institutions must use predictions constructively to provide tutoring and remedial aid rather than punitive measures.
            """
        )

        st.markdown("### 🔮 5. Future Enhancements")
        st.markdown(
            """
            - **LMS Integration**: Direct automated integration with Moodle, Canvas, and Google Classroom APIs.
            - **Deep Learning Sequence Models**: Applying LSTMs or Transformers to model weekly homework time-series trends.
            - **Automated Early-Warning Alerts**: Email and SMS notifications to academic counselors and student advisors.
            - **Explainability Extensions**: Integration with SHAP (SHapley Additive exPlanations) for local feature attribution.
            """
        )

    # Developer Information Card (Editable placeholders for student submission)
    with col2:
        st.markdown("### 👨‍🎓 Project & Student Credentials")
        st.markdown(
            """
            <div style="background:#F8FAFC; border:1px solid #E2E8F0; border-radius:12px; padding:20px; box-shadow:0 1px 3px rgba(0,0,0,0.05);">
                <div style="font-size:1.15rem; font-weight:700; color:#1E3A8A; margin-bottom:12px;">
                    🎓 MCA Project Submission Details
                </div>
                <table style="width:100%; font-size:0.88rem; line-height:1.7;">
                    <tr>
                        <td style="color:#64748B; font-weight:600;">Project Title:</td>
                        <td style="color:#1E293B; font-weight:700;">EduPredict AI</td>
                    </tr>
                    <tr>
                        <td style="color:#64748B; font-weight:600;">Course:</td>
                        <td style="color:#1E293B;">Master of Computer Applications (MCA)</td>
                    </tr>
                    <tr>
                        <td style="color:#64748B; font-weight:600;">Semester:</td>
                        <td style="color:#1E293B;">Final Year / Semester IV</td>
                    </tr>
                    <tr>
                        <td style="color:#64748B; font-weight:600;">Candidate Name:</td>
                        <td style="color:#1E293B; font-weight:600;">[Candidate Name / Roll No]</td>
                    </tr>
                    <tr>
                        <td style="color:#64748B; font-weight:600;">Enrollment No:</td>
                        <td style="color:#1E293B;">[MCA-2024-XXXX]</td>
                    </tr>
                    <tr>
                        <td style="color:#64748B; font-weight:600;">Department:</td>
                        <td style="color:#1E293B;">Dept. of Computer Applications / IT</td>
                    </tr>
                    <tr>
                        <td style="color:#64748B; font-weight:600;">University / College:</td>
                        <td style="color:#1E293B;">[University / Institute Name]</td>
                    </tr>
                    <tr>
                        <td style="color:#64748B; font-weight:600;">Internal Guide:</td>
                        <td style="color:#1E293B;">[Professor / Guide Name, Ph.D.]</td>
                    </tr>
                    <tr>
                        <td style="color:#64748B; font-weight:600;">Academic Year:</td>
                        <td style="color:#1E293B;">2024 – 2026</td>
                    </tr>
                </table>
                <div style="margin-top:16px; font-size:0.75rem; color:#94A3B8; text-align:center;">
                    <i>Editable placeholders — customize in <code>pages/5_About_Project.py</code></i>
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

        st.markdown("<br>", unsafe_allow_html=True)
        st.markdown("### 📁 Project Documentation Index")
        st.markdown(
            """
            The complete college submission documentation is saved in the `docs/` folder:
            
            - 📄 **`docs/project_synopsis.md`**: Formal project synopsis for college registration.
            - 📑 **`docs/project_report.md`**: Detailed 8-chapter academic project report.
            - ❓ **`docs/viva_questions.md`**: 40+ comprehensive viva voce questions with student-friendly answers.
            - 📈 **`docs/workflow.md`**: End-to-end data pipeline and deployment workflow guide.
            """
        )

if __name__ == "__main__":
    main()

