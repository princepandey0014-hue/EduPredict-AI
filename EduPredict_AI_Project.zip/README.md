# 🎓 EduPredict AI — Student Performance Prediction System Using Machine Learning

[![Python](https://img.shields.io/badge/Python-3.11-3776AB?logo=python&logoColor=white)](https://www.python.org/)
[![Streamlit](https://img.shields.io/badge/Streamlit-1.40+-FF4B4B?logo=streamlit&logoColor=white)](https://streamlit.io/)
[![Scikit-Learn](https://img.shields.io/badge/Scikit--Learn-1.4+-F7931E?logo=scikit-learn&logoColor=white)](https://scikit-learn.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

> **Master of Computer Applications (MCA) Project**  
> An end-to-end Machine Learning web application designed to forecast student final examination marks, categorize academic performance tiers, identify at-risk learners early in the semester, and provide explainable, personalized study improvement recommendations.

---

## 📌 Table of Contents

- [Project Overview](#-project-overview)
- [Key Features](#-key-features)
- [System Architecture](#-system-architecture)
- [Technology Stack](#-technology-stack)
- [Directory Structure](#-directory-structure)
- [Windows 10/11 Setup & Execution Guide](#-windows-1011-setup--execution-guide)
- [Dataset & Feature Schema](#-dataset--feature-schema)
- [Machine Learning Models & Genuine Benchmark Results](#-machine-learning-models--genuine-benchmark-results)
- [Web Application Pages](#-web-application-pages)
- [Documentation & Viva Resources](#-documentation--viva-resources)
- [Troubleshooting & Common Errors](#-troubleshooting--common-errors)
- [Academic Disclaimer](#-academic-disclaimer)

---

## 🚀 Project Overview

Predicting student academic performance is a cornerstone of **Educational Data Mining (EDM)** and **Learning Analytics**. Traditional academic evaluation is often reactive: struggling students are identified only after semester examination results are declared, when remedial intervention is too late.

**EduPredict AI** provides an intelligent, proactive solution. By analyzing behavioral indicators—including daily self-study hours, lecture attendance percentage, assignment submission rate, classroom participation, and prior examination performance—the system:
1. Predicts final examination marks (continuous 0–100 scale).
2. Classifies students into 4 standardized performance tiers (*Excellent*, *Good*, *Average*, *Needs Improvement*).
3. Detects students who require targeted academic mentoring.
4. Synthesizes transparent, explainable recommendations tailored to the student's unique profile.

---

## 🌟 Key Features

- **Multi-Algorithm Regression Engine**: Implements Linear Regression, Decision Tree Regressor, and Random Forest Regressor to predict final marks with genuine $R^2 \approx 0.94$.
- **Multi-Class Performance Categorization**: Implements Logistic Regression and Random Forest Classifier across 4 documented grade tiers with $\approx 85\%$ test accuracy.
- **Explainable AI (XAI) Personalized Recommendations**: Transparent heuristic recommendations identifying specific factors (e.g., attendance shortage, insufficient daily study, lagging coursework) and actionable remedies.
- **Interactive EDA & Visual Analytics**: Interactive Plotly scatter plots, trendlines, bivariate distributions, correlation heatmaps, and Gini-impurity feature importance charts.
- **Batch CSV Inference Engine**: Allows university administrators to upload new semester cohort CSV files, validates required headers, executes batch predictions, and provides exportable results.
- **Strict Anti-Data Leakage Pipeline**: Scikit-Learn `ColumnTransformer` (StandardScaler + OneHotEncoder) fitted exclusively on training data (80%) and transformed on test data (20%).
- **Model Persistence with Joblib**: Serializes trained pipelines and diagnostic metadata for fast inference without re-training on page reload.

---

## 🏗️ System Architecture

```
[ Raw Student Dataset (CSV) ]
             │
             ▼
[ Data Cleaning & Range Validation ]
             │
             ▼
[ 80 / 20 Stratified Train-Test Split ] (random_state=42)
             │
             ├──────────────────────────────────────────┐
             ▼                                          ▼
[ Fit Preprocessor on Train ]             [ Transform Test Holdout ]
(StandardScaler + OneHotEncoder)                        │
             │                                          │
             ▼                                          ▼
[ Train ML Models ]                       [ Test Evaluation ]
• Linear Regression                       • Regression: MAE, MSE, RMSE, R²
• Decision Tree Regressor                 • Classification: Accuracy, Precision,
• Random Forest Regressor                   Recall, F1-Score, Confusion Matrix
• Logistic Regression                                   │
             │                                          │
             └──────────────────┬───────────────────────┘
                                ▼
              [ Serialize Artifacts (.joblib) ]
                                │
                                ▼
         [ Streamlit Multi-Page Web Application ]
         ├── Home Dashboard (KPI Cards & Charts)
         ├── 1. Student Prediction (Gauge & Advice)
         ├── 2. Student Analytics (Interactive EDA)
         ├── 3. Model Performance (Benchmark & Residuals)
         ├── 4. Student Records (Directory & Batch CSV)
         └── 5. About Project (MCA Viva & Credentials)
```

---

## 💻 Technology Stack

| Layer | Library / Tool | Version | Purpose |
| :--- | :--- | :--- | :--- |
| **Language** | Python | 3.11.x | Core programming language |
| **Frontend UI** | Streamlit | ≥ 1.30.0 | Interactive web application framework |
| **Machine Learning** | Scikit-Learn | ≥ 1.3.0 | Regression, classification, and pipelines |
| **Data Processing** | Pandas | ≥ 2.0.0 | Dataframe manipulation and CSV I/O |
| **Numerical Computing** | NumPy | ≥ 1.24.0 | Vectorized array math and distributions |
| **Data Visualization** | Plotly & Matplotlib | ≥ 5.18.0 | Interactive web charts and diagnostic plots |
| **Model Persistence** | Joblib | ≥ 1.3.0 | Pipeline serialization to disk |
| **Environment** | VS Code & Windows | 10 / 11 | Development environment & PowerShell |

---

## 📂 Directory Structure

```
EduPredict-AI/
│
├── app.py                             # Main Streamlit dashboard application
├── requirements.txt                   # Project package dependencies
├── README.md                          # Main project guide & documentation
├── .gitignore                         # Git exclusion rules
│
├── data/
│   ├── student_performance.csv        # Primary dataset (1,500 records)
│   ├── sample_student_data.csv        # Holdout sample records with ground truth
│   ├── sample_input_template.csv      # Blank CSV template for batch prediction
│   └── generate_data.py               # Reproducible dataset generator script
│
├── models/
│   ├── best_model.joblib              # Best trained regression model (Linear Regression)
│   ├── classification_model.joblib    # Best trained classifier (Logistic Regression)
│   ├── preprocessing_pipeline.joblib  # Fitted ColumnTransformer (StandardScaler + OHE)
│   ├── all_models.joblib              # Dictionary of all 5 trained models
│   └── metrics.joblib                 # Test evaluation metrics, residuals & confusion matrix
│
├── src/
│   ├── __init__.py                    # Source package initializer
│   ├── data_preprocessing.py          # Cleaning, schema validation, and pipeline creation
│   ├── train_model.py                 # Training script, evaluation, and serialization
│   ├── predict.py                     # Inference engine (single student & batch CSV)
│   ├── evaluate_model.py              # Metric calculation routines (MAE, RMSE, R², F1)
│   └── recommendations.py             # Rule-based explainable recommendation engine
│
├── pages/
│   ├── 1_Student_Prediction.py        # Individual prediction form, gauge & recommendations
│   ├── 2_Student_Analytics.py         # Interactive EDA, correlation heatmap & feature importance
│   ├── 3_Model_Performance.py         # Comparative benchmark tables, residuals & confusion matrix
│   ├── 4_Student_Records.py           # Table viewer, filters, and batch CSV upload
│   └── 5_About_Project.py             # Synopsis, architecture, limitations & student credentials
│
├── assets/
│   ├── README.md                      # Asset folder documentation
│   └── style.css                      # Modern CSS styles for cards, badges & banners
│
└── docs/
    ├── project_synopsis.md            # Formal MCA project synopsis for college submission
    ├── project_report.md              # Detailed college-ready 8-chapter project report
    ├── viva_questions.md              # 40+ MCA viva questions with comprehensive answers
    └── workflow.md                    # Technical workflow and pipeline documentation
```

---

## 🪟 Windows 10/11 Setup & Execution Guide

Follow these beginner-friendly steps to set up and run the project inside **Visual Studio Code** on Windows.

### Step 1: Open the Project Folder in VS Code
1. Launch VS Code.
2. Select **File > Open Folder...** and choose `E:\Edu-predict AI` (or your chosen directory).
3. Open an integrated PowerShell terminal: Press `Ctrl + ~` (or select **Terminal > New Terminal**).

### Step 2: Create a Python Virtual Environment
Run the following command to create a clean virtual environment named `venv`:

```powershell
python -m venv venv
```

### Step 3: Activate the Virtual Environment
Activate the environment using PowerShell:

```powershell
.\venv\Scripts\Activate.ps1
```

> **Note on PowerShell Script Execution Policy:**  
> If Windows displays an error stating that *running scripts is disabled on this system*, run this command once in your current PowerShell session to temporarily permit local scripts:
> ```powershell
> Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope Process
> .\venv\Scripts\Activate.ps1
> ```
> *(This command applies strictly to the current terminal session without altering global Windows system security settings).*

### Step 4: Install Dependencies
Upgrade `pip` and install all required libraries:

```powershell
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

### Step 5: Train Machine Learning Models
Execute the training script. This script loads the dataset, performs the stratified train-test split, trains all 5 algorithms, calculates genuine test metrics, and saves the `.joblib` artifacts into `models/`:

```powershell
python -m src.train_model
```

### Step 6: Launch the Streamlit Web Application
Start the Streamlit application server:

```powershell
streamlit run app.py
```

### Step 7: Access the Application
The terminal will display the local network URL. Open your web browser and navigate to:
```
http://localhost:8501
```

---

## 📊 Dataset & Feature Schema

The primary dataset (`data/student_performance.csv`) comprises **1,500 student records** across 12 attributes:

| Column Name | Type | Valid Range / Categories | Description |
| :--- | :--- | :--- | :--- |
| `student_id` | String | `STD-1001` to `STD-2500` | Anonymized unique student identification key |
| `previous_marks` | Float | `0.0` to `100.0` | Marks obtained in prior semester / qualification examination |
| `study_hours_per_day` | Float | `0.0` to `12.0` | Average hours spent daily in self-directed study |
| `attendance_percentage`| Float | `0.0%` to `100.0%` | Classroom lecture and laboratory attendance rate |
| `assignment_completion_rate` | Float | `0.0%` to `100.0%` | Percentage of continuous internal coursework submitted |
| `extracurricular_hours`| Float | `0.0` to `24.0` | Weekly hours spent in athletics, clubs, or arts |
| `internet_access` | Category | `'Yes'`, `'No'` | Reliable internet access at residence |
| `family_support` | Category | `'High'`, `'Moderate'`, `'Low'` | Family encouragement and home study environment |
| `class_participation` | Category | `'High'`, `'Medium'`, `'Low'` | Frequency of classroom discussions and seminar engagement |
| `parental_education` | Category | `'High School'`, `'Bachelor'`, `'Master'`, `'Doctorate'` | Highest educational attainment of parents |
| **`final_marks`** | Float | `0.0` to `100.0` | **Target 1 (Regression)**: Final examination marks |
| **`performance_category`**| Category | *See Below* | **Target 2 (Classification)**: Grade performance tier |

### Documented Performance Category Thresholds

| Category Tier | Marks Range | Color Code | Academic Standing Description |
| :--- | :--- | :--- | :--- |
| **Excellent** | 80.0 – 100.0 | `#3B82F6` (Blue) | Distinction standing, high mastery, eligible for peer leadership |
| **Good** | 65.0 – 79.9 | `#10B981` (Green) | Consistent above-average comprehension and steady coursework |
| **Average** | 40.0 – 64.9 | `#F59E0B` (Amber) | Satisfactory pass, potential foundational gaps needing revision |
| **Needs Improvement**| Below 40.0 | `#EF4444` (Red) | High academic risk, fails pass criteria, mandatory remedial support |

---

## 🔬 Machine Learning Models & Genuine Benchmark Results

All metrics below are **strictly calculated from the actual unseen 20% test dataset (300 students)**.

### 1. Regression Algorithms Benchmark (Target: `final_marks`)

| Algorithm | MAE | MSE | RMSE | Test R² Score |
| :--- | :---: | :---: | :---: | :---: |
| **Linear Regression** *(Best)* | **2.8121** | **12.5987** | **3.5495** | **0.9408** |
| **Random Forest Regressor** | 3.3020 | 17.8302 | 4.2226 | 0.9162 |
| **Decision Tree Regressor** | 4.4543 | 32.5071 | 5.7015 | 0.8472 |

### 2. Classification Algorithms Benchmark (Target: `performance_category`)

| Algorithm | Accuracy | Precision (Weighted) | Recall (Weighted) | F1-Score (Weighted) | F1-Score (Macro) |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Logistic Regression** *(Best)* | **84.67%** | **85.08%** | **84.67%** | **84.60%** | **83.86%** |
| **Random Forest Classifier** | 81.33% | 81.63% | 81.33% | 80.89% | 76.82% |

> **Viva Insight on Model Selection:**  
> While ensemble methods like Random Forest excel on high-dimensional non-linear interactions, Linear Regression and multinomial Logistic Regression demonstrate superior generalization and minimal variance on this dataset. Linear Regression provides an exceptionally low RMSE of 3.55 marks and clear coefficient interpretability without overfitting.

---

## 🖥️ Web Application Pages

1. **`app.py` — Home Executive Dashboard**: Real-time KPI summary cards (Total students, average marks, pass rate, at-risk count), performance donut chart, marks distribution histogram, and quick action cards.
2. **`pages/1_Student_Prediction.py` — Student Prediction**: Form to input single student indicators, interactive Plotly semi-circular gauge, category confidence probabilities, key contributing factors, and explainable recommendations.
3. **`pages/2_Student_Analytics.py` — Student Analytics**: Interactive multi-filter exploratory dashboard with scatter plots, trendlines, attendance impact analysis, correlation heatmap, and Random Forest feature importance.
4. **`pages/3_Model_Performance.py` — Model Performance**: Detailed benchmark tables, actual vs. predicted scatter plot, residual plot for homoscedasticity inspection, multi-class confusion matrix, and bias-variance analysis.
5. **`pages/4_Student_Records.py` — Student Records & Batch Upload**: Interactive student search, filter by performance category/risk, dataset download, and drag-and-drop CSV batch prediction with download export.
6. **`pages/5_About_Project.py` — About Project & MCA Documentation**: Formal MCA project synopsis, architectural diagram, technology stack, ethical guidelines, and editable developer credentials card.

---

## 📑 Documentation & Viva Resources

College-level documentation is available inside the `docs/` folder:
- **`docs/project_synopsis.md`**: Formal academic synopsis for project approval.
- **`docs/project_report.md`**: Complete 8-chapter MCA project dissertation.
- **`docs/viva_questions.md`**: 40+ comprehensive viva questions with student-friendly answers.
- **`docs/workflow.md`**: Technical workflow, data flow, and deployment guide.

---

## 🛠️ Troubleshooting & Common Errors

| Issue | Cause | Solution |
| :--- | :--- | :--- |
| `File ... cannot be loaded because running scripts is disabled` | Windows PowerShell execution policy restriction | Run: `Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope Process` in the current terminal. |
| `ModuleNotFoundError: No module named 'src'` | Running script outside project root or without package flag | Run modules with the `-m` switch: `python -m src.train_model` from the project root. |
| `Port 8501 is already in use` | Another Streamlit process is running | Run on a different port: `streamlit run app.py --server.port 8502` |
| `Model file not found: models/best_model.joblib` | Application launched before training models | Run `python -m src.train_model` to generate the `.joblib` files. |

---

## ⚖️ Academic Disclaimer

*EduPredict AI is developed for academic demonstration and Educational Data Mining research. The generated predictions are statistical estimates based on historical behavioral patterns. They are intended for formative academic advising, early-warning alerts, and mentoring. They do not constitute a guarantee of future examination marks and must never be utilized as clinical, psychological, or disciplinary decisions.*

---

**Developed for Master of Computer Applications (MCA) Academic Submission**  
*Python • Streamlit • Scikit-Learn • Plotly • Joblib*

