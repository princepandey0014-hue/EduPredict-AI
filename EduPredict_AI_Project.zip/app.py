"""
EduPredict AI — Student Performance Prediction System
Main Streamlit Application Entrypoint & Executive Dashboard
MCA Level Project - Machine Learning & Educational Analytics
"""

import os
import sys
import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go

# Ensure project root is in sys.path
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from src.data_preprocessing import load_data, CATEGORY_ORDER
from src.predict import get_predictor

# Page configuration
st.set_page_config(
    page_title="EduPredict AI — Student Performance Prediction System",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Load custom CSS
css_path = os.path.join(BASE_DIR, "assets", "style.css")
if os.path.exists(css_path):
    with open(css_path, "r") as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

# Safe check for statsmodels (for OLS trendline rendering)
HAS_STATSMODELS = False
try:
    import statsmodels.api as sm
    HAS_STATSMODELS = True
except ImportError:
    pass

# Helper function to cache data loading
@st.cache_data
def get_cached_dataset():
    data_path = os.path.join(BASE_DIR, "data", "student_performance.csv")
    return load_data(data_path)

@st.cache_resource
def get_cached_predictor():
    try:
        return get_predictor()
    except Exception as e:
        return None

def main():
    # Sidebar
    with st.sidebar:
        st.markdown("## 🎓 EduPredict AI")
        st.caption("Student Performance Prediction System")
        st.markdown("---")
        
        st.markdown("### 📌 Navigation Guide")
        st.markdown(
            """
            - **🏠 Home Dashboard**: Overview & KPIs
            - **🔮 1. Student Prediction**: Individual AI estimation
            - **📊 2. Student Analytics**: Interactive EDA charts
            - **📈 3. Model Performance**: ML evaluation & metrics
            - **📋 4. Student Records**: Data exploration & batch CSV
            - **ℹ️ 5. About Project**: Viva & college documentation
            """
        )
        st.markdown("---")
        
        # System status indicator
        predictor = get_cached_predictor()
        if predictor is not None and predictor.metrics is not None:
            best_reg = predictor.metrics.get('best_reg_name', 'Trained Model')
            best_clf = predictor.metrics.get('best_clf_name', 'Trained Classifier')
            r2_val = predictor.metrics.get('regression_results', {}).get(best_reg, {}).get('r2', '0.94')
            st.success(f"✅ Models Loaded\n\n• Regressor: {best_reg} (R²: {r2_val})\n• Classifier: {best_clf}")
        else:
            st.warning("⚠️ Models need training. Run `python -m src.train_model`")
            
        st.markdown("---")
        st.markdown(
            """
            <div style='font-size:0.75rem; color:#64748b;'>
            <b>MCA Academic Project</b><br>
            Machine Learning Engineering<br>
            Python 3.11 • Streamlit • Scikit-Learn
            </div>
            """,
            unsafe_allow_html=True
        )

    # Hero Header Banner
    st.markdown(
        """
        <div class="hero-header">
            <div class="hero-title">🎓 EduPredict AI</div>
            <div class="hero-subtitle">
                Intelligent Student Academic Performance Prediction & Early-Intervention Support System
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )
    
    # Load dataset
    try:
        df = get_cached_dataset()
    except Exception as e:
        st.error(f"Error loading dataset: {e}. Please ensure `data/student_performance.csv` exists.")
        return

    # Calculate Actual Dashboard Metrics from genuine dataset
    total_students = len(df)
    avg_marks = df['final_marks'].mean()
    pass_rate = (df['final_marks'] >= 40.0).mean() * 100
    # Students needing academic support: marks < 50 or Category == 'Needs Improvement'
    at_risk_students = len(df[df['final_marks'] < 50.0])
    at_risk_pct = (at_risk_students / total_students) * 100
    excellent_students = len(df[df['final_marks'] >= 80.0])

    # Top KPI Metrics Cards Row
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.markdown(
            f"""
            <div class="metric-card">
                <div class="metric-title">Total Student Records</div>
                <div class="metric-value">{total_students:,}</div>
                <div class="metric-subtitle">Evaluated cohort size</div>
            </div>
            """,
            unsafe_allow_html=True
        )
    with col2:
        st.markdown(
            f"""
            <div class="metric-card">
                <div class="metric-title">Average Final Marks</div>
                <div class="metric-value">{avg_marks:.1f}<span style="font-size:1rem;color:#64748B;">/100</span></div>
                <div class="metric-subtitle">Std Dev: ±{df['final_marks'].std():.1f} marks</div>
            </div>
            """,
            unsafe_allow_html=True
        )
    with col3:
        st.markdown(
            f"""
            <div class="metric-card">
                <div class="metric-title">Institutional Pass Rate</div>
                <div class="metric-value">{pass_rate:.1f}%</div>
                <div class="metric-subtitle">Marks ≥ 40.0 threshold</div>
            </div>
            """,
            unsafe_allow_html=True
        )
    with col4:
        st.markdown(
            f"""
            <div class="metric-card" style="border-left: 4px solid #EF4444;">
                <div class="metric-title" style="color:#B91C1C;">At-Risk Students</div>
                <div class="metric-value" style="color:#DC2626;">{at_risk_students}</div>
                <div class="metric-subtitle">{at_risk_pct:.1f}% require academic support</div>
            </div>
            """,
            unsafe_allow_html=True
        )

    st.markdown("<br>", unsafe_allow_html=True)

    # Main Visuals Section: 2 Columns
    chart_col1, chart_col2 = st.columns([1, 1])

    with chart_col1:
        st.markdown("### 🍩 Performance Category Breakdown")
        cat_counts = df['performance_category'].value_counts().reindex(CATEGORY_ORDER).fillna(0)
        
        # Color mapping matching category themes
        color_map = {
            'Needs Improvement': '#EF4444',
            'Average': '#F59E0B',
            'Good': '#10B981',
            'Excellent': '#3B82F6'
        }
        
        donut_fig = go.Figure(data=[
            go.Pie(
                labels=cat_counts.index,
                values=cat_counts.values,
                hole=0.55,
                marker=dict(colors=[color_map[c] for c in cat_counts.index]),
                textinfo='label+percent',
                hovertemplate="<b>%{label}</b><br>Count: %{value}<br>Proportion: %{percent}<extra></extra>"
            )
        ])
        donut_fig.update_layout(
            showlegend=True,
            legend=dict(orientation="h", yanchor="bottom", y=-0.2, xanchor="center", x=0.5),
            margin=dict(l=20, r=20, t=20, b=30),
            height=340
        )
        st.plotly_chart(donut_fig, use_container_width=True)

    with chart_col2:
        st.markdown("### 📊 Final Marks Distribution")
        hist_fig = px.histogram(
            df,
            x="final_marks",
            nbins=25,
            color="performance_category",
            color_discrete_map=color_map,
            category_orders={"performance_category": CATEGORY_ORDER},
            labels={"final_marks": "Final Examination Marks (out of 100)", "count": "Student Count"}
        )
        # Add mean line
        hist_fig.add_vline(
            x=avg_marks,
            line_dash="dash",
            line_color="#1E3A8A",
            annotation_text=f"Mean: {avg_marks:.1f}",
            annotation_position="top right"
        )
        hist_fig.update_layout(
            margin=dict(l=20, r=20, t=20, b=30),
            height=340,
            bargap=0.08,
            legend=dict(orientation="h", yanchor="bottom", y=-0.2, xanchor="center", x=0.5)
        )
        st.plotly_chart(hist_fig, use_container_width=True)

    # Secondary Charts Row: Study Hours & Attendance Impact
    st.markdown("### 🔍 Key Academic Drivers Overview")
    row2_col1, row2_col2 = st.columns(2)

    with row2_col1:
        scatter_fig1 = px.scatter(
            df,
            x="study_hours_per_day",
            y="final_marks",
            color="performance_category",
            color_discrete_map=color_map,
            trendline="ols" if HAS_STATSMODELS else None,
            labels={"study_hours_per_day": "Daily Study Hours", "final_marks": "Final Examination Marks"},
            title="Study Hours vs. Final Marks (with Trendline)"
        )
        scatter_fig1.update_layout(height=320, margin=dict(l=20, r=20, t=35, b=20), showlegend=False)
        st.plotly_chart(scatter_fig1, use_container_width=True)

    with row2_col2:
        box_fig = px.box(
            df,
            x="class_participation",
            y="final_marks",
            color="class_participation",
            category_orders={"class_participation": ["Low", "Medium", "High"]},
            labels={"class_participation": "Class Participation Level", "final_marks": "Final Examination Marks"},
            title="Classroom Participation Impact on Final Marks"
        )
        box_fig.update_layout(height=320, margin=dict(l=20, r=20, t=35, b=20), showlegend=False)
        st.plotly_chart(box_fig, use_container_width=True)

    # Quick Navigation Cards
    st.markdown("### 🚀 Fast Access Portals")
    nav_c1, nav_c2, nav_c3 = st.columns(3)
    
    with nav_c1:
        st.info("🔮 **Predict Performance**\nEnter individual student metrics to estimate final examination scores, risk tiers, and personalized study suggestions.")
    with nav_c2:
        st.success("📊 **Interactive Analytics**\nDeep dive into bivariate distributions, attendance trends, feature correlation heatmaps, and feature importance rankings.")
    with nav_c3:
        st.warning("📋 **Batch Records & Upload**\nFilter student database, upload new cohort CSV files, generate batch predictions, and download exportable spreadsheets.")

    # Educational & Ethical Disclaimer
    st.markdown(
        """
        <div class="disclaimer-box">
            <b>⚖️ Ethical Machine Learning & Transparency Disclaimer:</b><br>
            The predictions generated by EduPredict AI are statistical estimations calculated by trained machine learning algorithms based on historical behavioral patterns. They are intended solely for academic advisory, formative guidance, and early-warning identification. Predictions do not guarantee future academic results and must not be used as clinical, psychological, or disciplinary determinations.
        </div>
        """,
        unsafe_allow_html=True
    )

if __name__ == "__main__":
    main()

