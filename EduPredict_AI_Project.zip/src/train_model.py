"""
Model training and evaluation script for EduPredict AI.
Trains Linear Regression, Decision Tree, Random Forest Regressor,
Logistic Regression, and Random Forest Classifier.
Evaluates models on genuine test data, selects the best performers,
and serializes artifacts to the models/ directory using Joblib.
"""

import os
import sys

# Ensure root directory is in sys.path for both module and direct execution
base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if base_dir not in sys.path:
    sys.path.insert(0, base_dir)

import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier

from src.data_preprocessing import (
    load_data,
    validate_dataframe,
    clean_data,
    build_preprocessor,
    prepare_train_test_split,
    FEATURE_COLUMNS,
    NUMERICAL_FEATURES,
    CATEGORICAL_FEATURES,
    CATEGORY_ORDER
)
from src.evaluate_model import (
    evaluate_regression,
    evaluate_classification,
    build_regression_comparison_df,
    build_classification_comparison_df
)

def get_transformed_feature_names(preprocessor) -> list[str]:
    """Retrieves human-readable feature names after OneHotEncoding."""
    try:
        cat_encoder = preprocessor.named_transformers_['cat'].named_steps['onehot']
        cat_cols = cat_encoder.get_feature_names_out(CATEGORICAL_FEATURES).tolist()
        return NUMERICAL_FEATURES + cat_cols
    except Exception:
        return [f"Feature_{i}" for i in range(17)]

def train_and_evaluate(data_path: str = None, models_dir: str = None):
    # Resolve file paths
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if data_path is None:
        data_path = os.path.join(base_dir, 'data', 'student_performance.csv')
    if models_dir is None:
        models_dir = os.path.join(base_dir, 'models')
        
    os.makedirs(models_dir, exist_ok=True)
    
    print("=" * 70)
    print("   EduPredict AI — Model Training and Benchmark Pipeline")
    print("=" * 70)
    
    # 1. Load dataset
    print(f"\n[1/7] Loading dataset from: {data_path}")
    raw_df = load_data(data_path)
    print(f"      Loaded {len(raw_df)} student records with {raw_df.shape[1]} columns.")
    
    # 2. Validate columns & ranges
    print("[2/7] Validating data integrity and schema...")
    is_valid, val_msg = validate_dataframe(raw_df, require_targets=True)
    if not is_valid:
        raise ValueError(f"Dataset validation failed: {val_msg}")
    print(f"      Validation Passed: {val_msg}")
    
    # 3. Clean data & check duplicates
    cleaned_df = clean_data(raw_df)
    
    # 4. Train-Test Split (Fixed random_state=42, no leakage)
    print("\n[3/7] Splitting data into Training (80%) and Testing (20%) sets...")
    X_train, X_test, y_reg_train, y_reg_test, y_clf_train, y_clf_test = prepare_train_test_split(
        cleaned_df, test_size=0.2, random_state=42
    )
    print(f"      Training samples : {len(X_train)}")
    print(f"      Testing samples  : {len(X_test)}")
    
    # 5. Fit Preprocessor on TRAIN SET ONLY
    print("\n[4/7] Fitting Preprocessing Pipeline (StandardScaler + OneHotEncoder)...")
    preprocessor = build_preprocessor()
    X_train_proc = preprocessor.fit_transform(X_train)
    X_test_proc = preprocessor.transform(X_test)
    feature_names = get_transformed_feature_names(preprocessor)
    print(f"      Transformed feature space: {X_train_proc.shape[1]} engineered features.")
    
    # 6. Train Regression Models
    print("\n[5/7] Training and evaluating Regression Models for Final Marks...")
    regressors = {
        'Linear Regression': LinearRegression(),
        'Decision Tree Regressor': DecisionTreeRegressor(max_depth=5, random_state=42),
        'Random Forest Regressor': RandomForestRegressor(n_estimators=120, max_depth=8, min_samples_split=4, random_state=42)
    }
    
    regression_results = {}
    regression_train_results = {}
    regression_preds = {}
    
    for name, model in regressors.items():
        print(f"      Fitting {name}...")
        model.fit(X_train_proc, y_reg_train)
        
        # Test evaluation
        y_pred_test = model.predict(X_test_proc)
        regression_preds[name] = y_pred_test
        test_metrics = evaluate_regression(y_reg_test, y_pred_test, model_name=name)
        regression_results[name] = test_metrics
        
        # Train evaluation (to monitor overfitting)
        y_pred_train = model.predict(X_train_proc)
        train_metrics = evaluate_regression(y_reg_train, y_pred_train, model_name=name)
        regression_train_results[name] = train_metrics
        
    reg_comparison_df = build_regression_comparison_df(regression_results)
    print("\n--- Regression Test Performance Comparison ---")
    print(reg_comparison_df.to_string(index=False))
    
    # Select Best Regressor based on highest R² (lowest RMSE)
    best_reg_name = reg_comparison_df.iloc[0]['Algorithm']
    best_reg_model = regressors[best_reg_name]
    print(f"\n>>> Selected Best Regression Model: '{best_reg_name}' (R² = {regression_results[best_reg_name]['r2']})")
    
    # 7. Train Classification Models
    print("\n[6/7] Training and evaluating Classification Models for Performance Category...")
    classifiers = {
        'Logistic Regression': LogisticRegression(max_iter=1000, random_state=42),
        'Random Forest Classifier': RandomForestClassifier(n_estimators=120, max_depth=8, min_samples_split=4, random_state=42)
    }
    
    classification_results = {}
    classification_train_results = {}
    classification_preds = {}
    
    for name, model in classifiers.items():
        print(f"      Fitting {name}...")
        model.fit(X_train_proc, y_clf_train)
        
        # Test evaluation
        y_pred_clf_test = model.predict(X_test_proc)
        classification_preds[name] = y_pred_clf_test
        test_metrics = evaluate_classification(y_clf_test, y_pred_clf_test, labels=CATEGORY_ORDER, model_name=name)
        classification_results[name] = test_metrics
        
        # Train evaluation
        y_pred_clf_train = model.predict(X_train_proc)
        train_metrics = evaluate_classification(y_clf_train, y_pred_clf_train, labels=CATEGORY_ORDER, model_name=name)
        classification_train_results[name] = train_metrics

    clf_comparison_df = build_classification_comparison_df(classification_results)
    print("\n--- Classification Test Performance Comparison ---")
    print(clf_comparison_df.to_string(index=False))
    
    # Select Best Classifier based on F1-Score (Weighted)
    best_clf_name = clf_comparison_df.iloc[0]['Algorithm']
    best_clf_model = classifiers[best_clf_name]
    print(f"\n>>> Selected Best Classification Model: '{best_clf_name}' (F1 = {classification_results[best_clf_name]['f1_weighted']})")
    
    # Feature Importances from Random Forest Regressor & Classifier
    rf_reg = regressors['Random Forest Regressor']
    rf_clf = classifiers['Random Forest Classifier']
    
    reg_importances = dict(zip(feature_names, [round(float(v), 4) for v in rf_reg.feature_importances_]))
    clf_importances = dict(zip(feature_names, [round(float(v), 4) for v in rf_clf.feature_importances_]))
    
    # 8. Save artifacts using Joblib
    print("\n[7/7] Persisting models and evaluation metrics with Joblib...")
    
    best_model_path = os.path.join(models_dir, 'best_model.joblib')
    joblib.dump(best_reg_model, best_model_path)
    print(f"      Saved: {best_model_path}")
    
    clf_model_path = os.path.join(models_dir, 'classification_model.joblib')
    joblib.dump(best_clf_model, clf_model_path)
    print(f"      Saved: {clf_model_path}")
    
    preprocessor_path = os.path.join(models_dir, 'preprocessing_pipeline.joblib')
    joblib.dump(preprocessor, preprocessor_path)
    print(f"      Saved: {preprocessor_path}")
    
    all_models_path = os.path.join(models_dir, 'all_models.joblib')
    joblib.dump({
        'regressors': regressors,
        'classifiers': classifiers,
        'best_reg_name': best_reg_name,
        'best_clf_name': best_clf_name
    }, all_models_path)
    print(f"      Saved: {all_models_path}")
    
    # Store complete metadata for frontend dashboards
    metrics_payload = {
        'train_size': len(X_train),
        'test_size': len(X_test),
        'total_size': len(cleaned_df),
        'feature_names': feature_names,
        'best_reg_name': best_reg_name,
        'best_clf_name': best_clf_name,
        'regression_results': regression_results,
        'regression_train_results': regression_train_results,
        'classification_results': classification_results,
        'classification_train_results': classification_train_results,
        'reg_importances': reg_importances,
        'clf_importances': clf_importances,
        # Store actual and predicted arrays for Plotly charts in Model Performance page
        'test_actual_reg': y_reg_test.tolist(),
        'test_pred_best_reg': regression_preds[best_reg_name].tolist(),
        'test_actual_clf': y_clf_test.tolist(),
        'test_pred_best_clf': classification_preds[best_clf_name].tolist(),
        'category_order': CATEGORY_ORDER
    }
    
    metrics_path = os.path.join(models_dir, 'metrics.joblib')
    joblib.dump(metrics_payload, metrics_path)
    print(f"      Saved: {metrics_path}")
    
    print("\n" + "=" * 70)
    print("   TRAINING AND PERSISTENCE COMPLETED SUCCESSFULLY!")
    print("=" * 70)
    return metrics_payload

if __name__ == '__main__':
    train_and_evaluate()
