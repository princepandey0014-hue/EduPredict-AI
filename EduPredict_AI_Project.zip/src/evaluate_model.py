"""
Model evaluation module for EduPredict AI.
Calculates comprehensive metrics for regression (MAE, MSE, RMSE, R²)
and classification (Accuracy, Precision, Recall, F1, Confusion Matrix).
"""

import numpy as np
import pandas as pd
from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report
)

def evaluate_regression(y_true, y_pred, model_name: str = "Regression Model") -> dict:
    """
    Computes standard regression performance metrics.
    """
    mae = float(mean_absolute_error(y_true, y_pred))
    mse = float(mean_squared_error(y_true, y_pred))
    rmse = float(np.sqrt(mse))
    r2 = float(r2_score(y_true, y_pred))
    
    return {
        'model_name': model_name,
        'mae': round(mae, 4),
        'mse': round(mse, 4),
        'rmse': round(rmse, 4),
        'r2': round(r2, 4)
    }

def evaluate_classification(y_true, y_pred, labels=None, model_name: str = "Classifier") -> dict:
    """
    Computes standard multi-class classification metrics.
    """
    if labels is None:
        labels = ['Needs Improvement', 'Average', 'Good', 'Excellent']
        
    acc = float(accuracy_score(y_true, y_pred))
    prec_weighted = float(precision_score(y_true, y_pred, average='weighted', zero_division=0))
    rec_weighted = float(recall_score(y_true, y_pred, average='weighted', zero_division=0))
    f1_weighted = float(f1_score(y_true, y_pred, average='weighted', zero_division=0))
    
    prec_macro = float(precision_score(y_true, y_pred, average='macro', zero_division=0))
    rec_macro = float(recall_score(y_true, y_pred, average='macro', zero_division=0))
    f1_macro = float(f1_score(y_true, y_pred, average='macro', zero_division=0))
    
    cm = confusion_matrix(y_true, y_pred, labels=labels).tolist()
    report = classification_report(y_true, y_pred, labels=labels, output_dict=True, zero_division=0)
    
    return {
        'model_name': model_name,
        'accuracy': round(acc, 4),
        'precision_weighted': round(prec_weighted, 4),
        'recall_weighted': round(rec_weighted, 4),
        'f1_weighted': round(f1_weighted, 4),
        'precision_macro': round(prec_macro, 4),
        'recall_macro': round(rec_macro, 4),
        'f1_macro': round(f1_macro, 4),
        'confusion_matrix': cm,
        'labels': labels,
        'report': report
    }

def build_regression_comparison_df(results_dict: dict) -> pd.DataFrame:
    """Formats regression evaluation dictionary into a clean pandas DataFrame."""
    rows = []
    for name, metrics in results_dict.items():
        rows.append({
            'Algorithm': name,
            'MAE': metrics['mae'],
            'MSE': metrics['mse'],
            'RMSE': metrics['rmse'],
            'R² Score': metrics['r2']
        })
    df = pd.DataFrame(rows)
    return df.sort_values(by='R² Score', ascending=False).reset_index(drop=True)

def build_classification_comparison_df(results_dict: dict) -> pd.DataFrame:
    """Formats classification evaluation dictionary into a clean pandas DataFrame."""
    rows = []
    for name, metrics in results_dict.items():
        rows.append({
            'Algorithm': name,
            'Accuracy': metrics['accuracy'],
            'Precision (Weighted)': metrics['precision_weighted'],
            'Recall (Weighted)': metrics['recall_weighted'],
            'F1-Score (Weighted)': metrics['f1_weighted'],
            'F1-Score (Macro)': metrics['f1_macro']
        })
    df = pd.DataFrame(rows)
    return df.sort_values(by='F1-Score (Weighted)', ascending=False).reset_index(drop=True)

