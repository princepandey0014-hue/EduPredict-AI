"""
Data preprocessing, cleaning, and transformation pipeline for EduPredict AI.
Handles missing values, duplicate removal, categorical encoding, feature scaling,
and data validation without data leakage.
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
import joblib
import os

NUMERICAL_FEATURES = [
    'previous_marks',
    'study_hours_per_day',
    'attendance_percentage',
    'assignment_completion_rate',
    'extracurricular_hours'
]

CATEGORICAL_FEATURES = [
    'internet_access',
    'family_support',
    'class_participation',
    'parental_education'
]

FEATURE_COLUMNS = NUMERICAL_FEATURES + CATEGORICAL_FEATURES
TARGET_REGRESSION = 'final_marks'
TARGET_CLASSIFICATION = 'performance_category'

# Explicit performance category threshold boundaries
CATEGORY_THRESHOLDS = {
    'Excellent': (80.0, 100.0),
    'Good': (65.0, 79.99),
    'Average': (40.0, 64.99),
    'Needs Improvement': (0.0, 39.99)
}

CATEGORY_ORDER = ['Needs Improvement', 'Average', 'Good', 'Excellent']

def map_marks_to_category(marks: float) -> str:
    """Categorizes marks into standard documented academic performance tiers."""
    if marks >= 80.0:
        return 'Excellent'
    elif marks >= 65.0:
        return 'Good'
    elif marks >= 40.0:
        return 'Average'
    else:
        return 'Needs Improvement'

def load_data(filepath: str) -> pd.DataFrame:
    """Loads CSV dataset with basic safety checks."""
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"Dataset file not found at: {filepath}")
    df = pd.read_csv(filepath)
    return df

def validate_dataframe(df: pd.DataFrame, require_targets: bool = True) -> tuple[bool, str]:
    """
    Validates that the input dataframe has the required schema and reasonable values.
    Returns (is_valid, error_message).
    """
    missing_cols = [col for col in FEATURE_COLUMNS if col not in df.columns]
    if missing_cols:
        return False, f"Missing required feature columns: {', '.join(missing_cols)}"
    
    if require_targets:
        if TARGET_REGRESSION not in df.columns:
            return False, f"Missing target column: '{TARGET_REGRESSION}'"
    
    # Check numerical bounds
    if (df['previous_marks'] < 0).any() or (df['previous_marks'] > 100).any():
        return False, "Column 'previous_marks' contains values outside [0, 100]."
    if (df['attendance_percentage'] < 0).any() or (df['attendance_percentage'] > 100).any():
        return False, "Column 'attendance_percentage' contains values outside [0, 100]."
    if (df['assignment_completion_rate'] < 0).any() or (df['assignment_completion_rate'] > 100).any():
        return False, "Column 'assignment_completion_rate' contains values outside [0, 100]."
    if (df['study_hours_per_day'] < 0).any() or (df['study_hours_per_day'] > 24).any():
        return False, "Column 'study_hours_per_day' contains invalid values (must be 0 - 24)."

    return True, "Dataframe schema and range validation passed."

def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    Removes duplicates, handles missing values, and ensures proper categorical types.
    """
    cleaned_df = df.copy()
    
    # 1. Deduplication
    initial_count = len(cleaned_df)
    cleaned_df = cleaned_df.drop_duplicates()
    duplicates_removed = initial_count - len(cleaned_df)
    if duplicates_removed > 0:
        print(f"[Preprocessing] Removed {duplicates_removed} duplicate records.")
    
    # 2. Impute missing numericals with median if any exist
    for col in NUMERICAL_FEATURES:
        if col in cleaned_df.columns and cleaned_df[col].isnull().sum() > 0:
            median_val = cleaned_df[col].median()
            cleaned_df[col] = cleaned_df[col].fillna(median_val)
            print(f"[Preprocessing] Imputed missing values in '{col}' with median: {median_val}")
            
    # 3. Impute missing categoricals with mode if any exist
    for col in CATEGORICAL_FEATURES:
        if col in cleaned_df.columns and cleaned_df[col].isnull().sum() > 0:
            mode_val = cleaned_df[col].mode()[0]
            cleaned_df[col] = cleaned_df[col].fillna(mode_val)
            print(f"[Preprocessing] Imputed missing values in '{col}' with mode: {mode_val}")
            
    # 4. If classification target is missing but regression target exists, compute it
    if TARGET_REGRESSION in cleaned_df.columns and TARGET_CLASSIFICATION not in cleaned_df.columns:
        cleaned_df[TARGET_CLASSIFICATION] = cleaned_df[TARGET_REGRESSION].apply(map_marks_to_category)

    return cleaned_df

def build_preprocessor() -> ColumnTransformer:
    """
    Constructs an sklearn ColumnTransformer pipeline for numerical scaling
    and one-hot encoding for categorical variables.
    """
    numeric_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler())
    ])
    
    categorical_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='most_frequent')),
        ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
    ])
    
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', numeric_transformer, NUMERICAL_FEATURES),
            ('cat', categorical_transformer, CATEGORICAL_FEATURES)
        ]
    )
    return preprocessor

def prepare_train_test_split(df: pd.DataFrame, test_size: float = 0.2, random_state: int = 42):
    """
    Splits features and targets into training and testing sets cleanly.
    Ensures NO data leakage: preprocessing must be fitted on train set only.
    """
    X = df[FEATURE_COLUMNS].copy()
    y_reg = df[TARGET_REGRESSION].copy()
    y_clf = df[TARGET_CLASSIFICATION].copy()
    
    # Stratify by classification category to ensure representative distribution across splits
    X_train, X_test, y_reg_train, y_reg_test, y_clf_train, y_clf_test = train_test_split(
        X, y_reg, y_clf,
        test_size=test_size,
        random_state=random_state,
        stratify=y_clf
    )
    
    return X_train, X_test, y_reg_train, y_reg_test, y_clf_train, y_clf_test

if __name__ == '__main__':
    data_path = os.path.join(os.path.dirname(__file__), '..', 'data', 'student_performance.csv')
    raw_df = load_data(data_path)
    is_valid, msg = validate_dataframe(raw_df)
    print(f"Validation status: {is_valid} ({msg})")
    cleaned = clean_data(raw_df)
    X_train, X_test, y_reg_train, y_reg_test, y_clf_train, y_clf_test = prepare_train_test_split(cleaned)
    print(f"Train samples: {len(X_train)}, Test samples: {len(X_test)}")
    preprocessor = build_preprocessor()
    X_train_proc = preprocessor.fit_transform(X_train)
    X_test_proc = preprocessor.transform(X_test)
    print(f"Processed feature matrix shape: {X_train_proc.shape}")

