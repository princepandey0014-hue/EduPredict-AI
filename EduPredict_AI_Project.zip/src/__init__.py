"""
EduPredict AI - Student Performance Prediction System
Core Machine Learning Source Package
"""

__version__ = "1.0.0"
__author__ = "EduPredict AI Team"

