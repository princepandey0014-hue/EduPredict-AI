"""
Personalized study recommendation engine for EduPredict AI.
Provides actionable, explainable educational suggestions based on student profile features.
Adheres to ethical guidelines: recommendations are transparent educational guidance,
not medical, psychological, or guaranteed academic predictions.
"""

def generate_recommendations(student_data: dict, predicted_marks: float, predicted_category: str) -> list[dict]:
    """
    Generates structured recommendations based on input features and predicted outcomes.
    
    Each recommendation is a dictionary:
    {
        'category': 'Attendance' | 'Study Habits' | 'Coursework' | 'Academic Foundation' | 'Lifestyle Balance' | 'Enrichment',
        'severity': 'critical' | 'warning' | 'info' | 'positive',
        'title': str,
        'message': str,
        'action_item': str
    }
    """
    recs = []
    
    prev_marks = float(student_data.get('previous_marks', 0))
    study_hours = float(student_data.get('study_hours_per_day', 0))
    attendance = float(student_data.get('attendance_percentage', 0))
    assignment_rate = float(student_data.get('assignment_completion_rate', 0))
    ec_hours = float(student_data.get('extracurricular_hours', 0))
    participation = str(student_data.get('class_participation', 'Medium'))
    internet = str(student_data.get('internet_access', 'Yes'))
    support = str(student_data.get('family_support', 'Moderate'))
    
    # 1. Attendance Analysis
    if attendance < 75.0:
        recs.append({
            'category': 'Attendance',
            'severity': 'critical',
            'title': 'Critical Attendance Shortage Alert',
            'message': f'Current attendance is {attendance}%, which is below the mandatory 75% institutional requirement. Regular absence significantly correlates with lower exam performance.',
            'action_item': 'Prioritize attending all upcoming lectures and practical labs without unexcused absences to regain eligibility.'
        })
    elif attendance < 85.0:
        recs.append({
            'category': 'Attendance',
            'severity': 'warning',
            'title': 'Attendance Improvement Opportunity',
            'message': f'Current attendance is {attendance}%. While meeting the minimum threshold, maintaining attendance above 85% strongly reinforces retention.',
            'action_item': 'Set morning reminders and review course timetables to maintain steady lecture attendance.'
        })
    else:
        recs.append({
            'category': 'Attendance',
            'severity': 'positive',
            'title': 'Exemplary Lecture Attendance',
            'message': f'Outstanding attendance record ({attendance}%). Consistent lecture engagement provides a solid foundation for exam preparation.',
            'action_item': 'Continue your disciplined attendance streak throughout the semester.'
        })
        
    # 2. Daily Study Hours
    if study_hours < 2.0:
        recs.append({
            'category': 'Study Habits',
            'severity': 'critical',
            'title': 'Insufficient Daily Self-Study',
            'message': f'Recorded self-study is only {study_hours} hour(s)/day. Higher-tier academic retention typically demands dedicated revision outside classroom hours.',
            'action_item': 'Establish a structured 2.5 to 3.5 hour daily study schedule using techniques like the Pomodoro method (25-min focus, 5-min break).'
        })
    elif study_hours < 4.0:
        recs.append({
            'category': 'Study Habits',
            'severity': 'info',
            'title': 'Moderate Self-Study Routine',
            'message': f'Devoting {study_hours} hours/day to self-study is moderate. Increasing this by 45-60 minutes daily can yield noticeable score gains.',
            'action_item': 'Allocate specific 45-minute slots for daily concept summarization and solving practice problems.'
        })
    else:
        recs.append({
            'category': 'Study Habits',
            'severity': 'positive',
            'title': 'High Dedication to Self-Study',
            'message': f'Commendable effort of {study_hours} hours/day. Consistent self-directed learning is strongly predictive of high examination performance.',
            'action_item': 'Ensure rest intervals and adequate sleep to prevent cognitive fatigue and burnout.'
        })
        
    # 3. Assignment Completion Rate
    if assignment_rate < 60.0:
        recs.append({
            'category': 'Coursework',
            'severity': 'critical',
            'title': 'Lagging Assignment Submissions',
            'message': f'Assignment completion rate is {assignment_rate}%. Continuous internal assessments directly impact internal marks and conceptual readiness.',
            'action_item': 'Track homework and project deadlines on a visual calendar or task app; submit pending assignments promptly.'
        })
    elif assignment_rate < 80.0:
        recs.append({
            'category': 'Coursework',
            'severity': 'warning',
            'title': 'Incomplete Practical Assignments',
            'message': f'Assignment completion stands at {assignment_rate}%. Completing the remaining assignments will solidify subject mastery.',
            'action_item': 'Aim for 90%+ timely completion by starting assignments within 48 hours of assignment announcement.'
        })
    else:
        recs.append({
            'category': 'Coursework',
            'severity': 'positive',
            'title': 'Diligent Assignment Track Record',
            'message': f'Excellent coursework completion ({assignment_rate}%). Timely submissions reflect strong task management.',
            'action_item': 'Leverage assignments as revision guides when preparing for midterms and finals.'
        })
        
    # 4. Previous Marks / Foundational Knowledge
    if prev_marks < 45.0:
        recs.append({
            'category': 'Academic Foundation',
            'severity': 'critical',
            'title': 'Foundational Knowledge Remediation',
            'message': f'Previous score was {prev_marks}/100. Addressing prerequisite gaps is critical before moving to advanced syllabus modules.',
            'action_item': 'Consult subject professors during office hours and attend remedial/tutorial support sessions.'
        })
    elif prev_marks < 65.0:
        recs.append({
            'category': 'Academic Foundation',
            'severity': 'warning',
            'title': 'Core Concept Reinforcement',
            'message': f'Previous score was {prev_marks}/100. Focused revision on past question papers will bridge the gap to higher grades.',
            'action_item': 'Solve previous 3 years examination question papers under timed conditions.'
        })
        
    # 5. Extracurricular Balance
    if ec_hours > 6.0 and study_hours < 2.5:
        recs.append({
            'category': 'Lifestyle Balance',
            'severity': 'warning',
            'title': 'Extracurricular vs Study Rebalancing Needed',
            'message': f'High extracurricular commitment ({ec_hours} hrs/week) coupled with lower study time ({study_hours} hrs/day) may cause time-management strain.',
            'action_item': 'Temporarily reallocate 2-3 extracurricular hours toward academic study during peak exam weeks.'
        })
    elif ec_hours == 0.0:
        recs.append({
            'category': 'Lifestyle Balance',
            'severity': 'info',
            'title': 'Incorporate Co-Curricular Activities',
            'message': 'No hours logged for extracurricular activities. Moderate physical activity or clubs enhance mental wellbeing and study focus.',
            'action_item': 'Incorporate 2-3 hours per week of sports, technical clubs, or creative hobbies for mental rejuvenation.'
        })
        
    # 6. Class Participation & Academic Support
    if participation == 'Low':
        recs.append({
            'category': 'Academic Foundation',
            'severity': 'info',
            'title': 'Active Classroom Engagement',
            'message': 'Recorded class participation is low. Interactive discussions significantly boost clarity on complex concepts.',
            'action_item': 'Try to ask at least one question or participate in group discussions during each class session.'
        })
        
    # 7. High Performer Guidance
    if predicted_marks >= 80.0 or predicted_category == 'Excellent':
        recs.append({
            'category': 'Enrichment',
            'severity': 'positive',
            'title': 'Advanced Enrichment & Peer Leadership',
            'message': f'Your projected score ({predicted_marks:.1f} / 100) positions you in the top tier (Excellent Category).',
            'action_item': 'Explore competitive coding, advanced certifications, research papers, or peer mentoring opportunities.'
        })
        
    return recs

