"""
Inference and prediction engine for EduPredict AI.
Handles single-student and batch predictions using trained models and preprocessing pipelines.
Provides risk assessment, key contributing factors, and explainable recommendations.
"""

import os
import sys
base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if base_dir not in sys.path:
    sys.path.insert(0, base_dir)

import joblib
import numpy as np
import pandas as pd
from src.data_preprocessing import (
    FEATURE_COLUMNS,
    NUMERICAL_FEATURES,
    CATEGORICAL_FEATURES,
    CATEGORY_ORDER,
    map_marks_to_category,
    clean_data
)
from src.recommendations import generate_recommendations

class Predictor:
    """Singleton predictor that loads artifacts once and serves predictions."""
    def __init__(self, models_dir: str = None):
        if models_dir is None:
            models_dir = os.path.join(base_dir, 'models')
        self.models_dir = models_dir
        
        self.reg_model_path = os.path.join(models_dir, 'best_model.joblib')
        self.clf_model_path = os.path.join(models_dir, 'classification_model.joblib')
        self.prep_path = os.path.join(models_dir, 'preprocessing_pipeline.joblib')
        self.metrics_path = os.path.join(models_dir, 'metrics.joblib')
        
        self.reg_model = None
        self.clf_model = None
        self.preprocessor = None
        self.metrics = None
        
        self._load_artifacts()
        
    def _load_artifacts(self):
        """Loads serialized machine learning artifacts with descriptive error handling."""
        if not os.path.exists(self.reg_model_path):
            raise FileNotFoundError(f"Model file not found: {self.reg_model_path}. Please run train_model first.")
        if not os.path.exists(self.clf_model_path):
            raise FileNotFoundError(f"Classifier file not found: {self.clf_model_path}.")
        if not os.path.exists(self.prep_path):
            raise FileNotFoundError(f"Preprocessor file not found: {self.prep_path}.")
            
        self.reg_model = joblib.load(self.reg_model_path)
        self.clf_model = joblib.load(self.clf_model_path)
        self.preprocessor = joblib.load(self.prep_path)
        
        if os.path.exists(self.metrics_path):
            self.metrics = joblib.load(self.metrics_path)
        else:
            self.metrics = {}

    def predict_single(self, input_dict: dict) -> dict:
        """
        Runs prediction for a single student.
        Returns marks, category, risk assessment, key factors, and personalized recommendations.
        """
        # Create single row DataFrame
        input_df = pd.DataFrame([input_dict])
        
        # Ensure all required features are present
        for col in FEATURE_COLUMNS:
            if col not in input_df.columns:
                raise ValueError(f"Missing required input feature: '{col}'")
                
        # Transform features using preprocessor
        X_proc = self.preprocessor.transform(input_df[FEATURE_COLUMNS])
        
        # Predict continuous marks
        raw_pred_marks = float(self.reg_model.predict(X_proc)[0])
        predicted_marks = round(max(0.0, min(100.0, raw_pred_marks)), 1)
        
        # Predict classification category
        predicted_category = str(self.clf_model.predict(X_proc)[0])
        
        # If probabilities are supported
        cat_probabilities = {}
        if hasattr(self.clf_model, 'predict_proba'):
            probs = self.clf_model.predict_proba(X_proc)[0]
            classes = self.clf_model.classes_
            cat_probabilities = {cls: round(float(p) * 100, 1) for cls, p in zip(classes, probs)}
            
        # Determine Academic Risk Status
        if predicted_marks < 40.0 or predicted_category == 'Needs Improvement':
            risk_level = 'High Academic Risk'
            risk_color = '#EF4444' # Red
            support_needed = True
        elif predicted_marks < 65.0 or predicted_category == 'Average':
            risk_level = 'Moderate Attention Needed'
            risk_color = '#F59E0B' # Amber
            support_needed = True
        elif predicted_marks < 80.0:
            risk_level = 'Good Academic Standing'
            risk_color = '#10B981' # Green
            support_needed = False
        else:
            risk_level = 'Distinction / High Standing'
            risk_color = '#6366F1' # Indigo
            support_needed = False
            
        # Identify key driving factors (explainability)
        key_factors = self._analyze_contributing_factors(input_dict, predicted_marks)
        
        # Generate personalized recommendations
        recommendations = generate_recommendations(input_dict, predicted_marks, predicted_category)
        
        return {
            'predicted_marks': predicted_marks,
            'predicted_category': predicted_category,
            'category_probabilities': cat_probabilities,
            'risk_level': risk_level,
            'risk_color': risk_color,
            'support_needed': support_needed,
            'key_factors': key_factors,
            'recommendations': recommendations,
            'model_name': getattr(self.reg_model, '__class__', type(self.reg_model)).__name__
        }
        
    def _analyze_contributing_factors(self, data: dict, predicted_marks: float) -> list[dict]:
        """
        Transparent rule-based factor attribution explaining why the score was predicted.
        """
        factors = []
        
        att = float(data.get('attendance_percentage', 0))
        if att >= 85:
            factors.append({'factor': 'Strong Attendance', 'impact': 'Positive (+)', 'desc': f'{att}% attendance reinforces classroom comprehension.'})
        elif att < 75:
            factors.append({'factor': 'Attendance Shortage', 'impact': 'Negative (-)', 'desc': f'{att}% attendance limits contact learning hours.'})
            
        study = float(data.get('study_hours_per_day', 0))
        if study >= 4.0:
            factors.append({'factor': 'Dedicated Self-Study', 'impact': 'Positive (+)', 'desc': f'{study} hrs/day dedicated study yields strong concept mastery.'})
        elif study < 2.0:
            factors.append({'factor': 'Low Daily Study', 'impact': 'Negative (-)', 'desc': f'{study} hrs/day is insufficient for deeper curriculum retention.'})
            
        prev = float(data.get('previous_marks', 0))
        if prev >= 75:
            factors.append({'factor': 'Strong Academic Foundation', 'impact': 'Positive (+)', 'desc': f'Prior score of {prev}/100 indicates solid prerequisite command.'})
        elif prev < 50:
            factors.append({'factor': 'Weak Prerequisite Scores', 'impact': 'Negative (-)', 'desc': f'Prior score of {prev}/100 indicates foundational knowledge gaps.'})
            
        assign = float(data.get('assignment_completion_rate', 0))
        if assign >= 85:
            factors.append({'factor': 'Consistent Coursework', 'impact': 'Positive (+)', 'desc': f'{assign}% completion rate reflects steady academic work.'})
        elif assign < 60:
            factors.append({'factor': 'Lagging Coursework', 'impact': 'Negative (-)', 'desc': f'{assign}% assignment completion affects practical readiness.'})
            
        part = data.get('class_participation', 'Medium')
        if part == 'High':
            factors.append({'factor': 'Active Classroom Engagement', 'impact': 'Positive (+)', 'desc': 'Frequent classroom participation aids concept retention.'})
        elif part == 'Low':
            factors.append({'factor': 'Passive Engagement', 'impact': 'Negative (-)', 'desc': 'Low interactive participation during academic sessions.'})
            
        return factors

    def predict_batch(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Runs batch prediction on an uploaded or provided DataFrame.
        Returns a new DataFrame containing original features plus predictions and risk statuses.
        """
        # Validate columns
        for col in FEATURE_COLUMNS:
            if col not in df.columns:
                raise ValueError(f"Uploaded CSV missing required column: '{col}'")
                
        # Clean dataframe copy
        df_clean = clean_data(df)
        
        # Transform
        X_proc = self.preprocessor.transform(df_clean[FEATURE_COLUMNS])
        
        # Predict
        raw_marks = self.reg_model.predict(X_proc)
        pred_marks = np.clip(raw_marks, 0.0, 100.0).round(1)
        pred_categories = self.clf_model.predict(X_proc)
        
        # Assign outputs
        result_df = df_clean.copy()
        result_df['predicted_marks'] = pred_marks
        result_df['predicted_category'] = pred_categories
        
        def assign_risk(row):
            m = row['predicted_marks']
            cat = row['predicted_category']
            if m < 40.0 or cat == 'Needs Improvement':
                return 'High Academic Risk'
            elif m < 65.0 or cat == 'Average':
                return 'Moderate Attention'
            elif m < 80.0:
                return 'Good Standing'
            else:
                return 'Distinction'
                
        result_df['academic_risk'] = result_df.apply(assign_risk, axis=1)
        result_df['needs_academic_support'] = result_df['predicted_marks'] < 50.0
        
        return result_df

# Global convenience helper
_predictor_instance = None

def get_predictor():
    global _predictor_instance
    if _predictor_instance is None:
        _predictor_instance = Predictor()
    return _predictor_instance

