"""
Generate realistic student performance dataset for EduPredict AI.
Simulates academic indicators with realistic correlations, variance, and distributions across all performance categories.
"""

import numpy as np
import pandas as pd
import os

def generate_student_dataset(n_samples=1500, random_state=42):
    np.random.seed(random_state)
    
    # 1. Feature generation
    student_ids = [f"STD-{1000 + i}" for i in range(1, n_samples + 1)]
    
    # Latent student motivation & academic factor (standard normal)
    latent_ability = np.random.normal(0, 1.0, n_samples)
    
    # Previous marks: range 25.0 to 98.0
    prev_raw = 66.0 + 15.0 * latent_ability + np.random.normal(0, 6.0, n_samples)
    previous_marks = np.clip(prev_raw, 25.0, 98.0).round(1)
    
    # Attendance percentage: 40.0% to 100.0%
    att_raw = 78.0 + 13.0 * latent_ability + np.random.normal(0, 7.0, n_samples)
    attendance_percentage = np.clip(att_raw, 40.0, 100.0).round(1)
    
    # Study hours per day: 0.5 to 9.5 hours
    study_raw = 3.6 + 1.5 * latent_ability + np.random.exponential(0.7, n_samples)
    study_hours_per_day = np.clip(study_raw, 0.5, 9.5).round(1)
    
    # Assignment completion rate (%): 30.0% to 100.0%
    assign_raw = 0.45 * attendance_percentage + 0.35 * previous_marks + np.random.normal(0, 7.0, n_samples)
    assignment_rate = np.clip((assign_raw - assign_raw.min()) / (assign_raw.max() - assign_raw.min()) * 70.0 + 30.0, 30.0, 100.0).round(1)
    
    # Extracurricular hours per week (0 to 12)
    extracurricular_hours = np.clip(np.random.gamma(2.2, 1.3, n_samples), 0.0, 12.0).round(1)
    
    # Internet access: 88% Yes, 12% No
    prob_internet = 1 / (1 + np.exp(-(2.0 + 0.4 * latent_ability)))
    internet_access = np.where(np.random.rand(n_samples) < prob_internet, 'Yes', 'No')
    
    # Family educational support: High (32%), Moderate (50%), Low (18%)
    family_support = np.random.choice(['High', 'Moderate', 'Low'], size=n_samples, p=[0.32, 0.50, 0.18])
    
    # Class participation: High (28%), Medium (50%), Low (22%)
    part_weights = np.where(latent_ability > 0.5, 0, np.where(latent_ability < -0.5, 2, 1))
    class_participation = []
    for w in part_weights:
        if w == 0:
            class_participation.append(np.random.choice(['High', 'Medium', 'Low'], p=[0.60, 0.35, 0.05]))
        elif w == 2:
            class_participation.append(np.random.choice(['High', 'Medium', 'Low'], p=[0.08, 0.42, 0.50]))
        else:
            class_participation.append(np.random.choice(['High', 'Medium', 'Low'], p=[0.25, 0.55, 0.20]))
    class_participation = np.array(class_participation)
    
    # Parental education
    parental_education = np.random.choice(
        ['High School', 'Bachelor', 'Master', 'Doctorate'],
        size=n_samples,
        p=[0.26, 0.44, 0.22, 0.08]
    )
    
    # 2. Compute final examination marks based on educational domain factors
    support_bonus = np.where(family_support == 'High', 2.8, np.where(family_support == 'Moderate', 0.5, -2.8))
    part_bonus = np.where(class_participation == 'High', 3.2, np.where(class_participation == 'Medium', 0.5, -2.4))
    internet_bonus = np.where(internet_access == 'Yes', 1.8, -2.2)
    
    # Study hours effect (positive linear + diminishing return)
    effective_study = np.minimum(study_hours_per_day, 6.0) * 2.2 + np.maximum(0, study_hours_per_day - 6.0) * 0.7
    
    # Extracurricular: moderate is good, excessive (> 8 hrs) with low study hurts
    ec_effect = np.where(
        extracurricular_hours <= 4.0,
        extracurricular_hours * 0.3,
        1.2 - (extracurricular_hours - 4.0) * 0.3
    )
    
    # Weighted educational formula
    raw_final = (
        0.35 * previous_marks +
        0.25 * attendance_percentage +
        0.18 * assignment_rate +
        effective_study +
        support_bonus +
        part_bonus +
        internet_bonus +
        ec_effect - 2.5
    )
    
    # Exam variance (normal day-of-exam fluctuations)
    exam_noise = np.random.normal(0, 3.4, n_samples)
    final_marks = np.clip(raw_final + exam_noise, 20.0, 99.0).round(1)
    
    # 3. Categorize performance according to documented thresholds:
    # Excellent: 80 - 100
    # Good: 65 - 79
    # Average: 40 - 64
    # Needs Improvement: Below 40
    def categorize(m):
        if m >= 80.0:
            return 'Excellent'
        elif m >= 65.0:
            return 'Good'
        elif m >= 40.0:
            return 'Average'
        else:
            return 'Needs Improvement'
            
    performance_category = [categorize(m) for m in final_marks]
    
    df = pd.DataFrame({
        'student_id': student_ids,
        'previous_marks': previous_marks,
        'study_hours_per_day': study_hours_per_day,
        'attendance_percentage': attendance_percentage,
        'assignment_completion_rate': assignment_rate,
        'extracurricular_hours': extracurricular_hours,
        'internet_access': internet_access,
        'family_support': family_support,
        'class_participation': class_participation,
        'parental_education': parental_education,
        'final_marks': final_marks,
        'performance_category': performance_category
    })
    
    return df

if __name__ == '__main__':
    os.makedirs('data', exist_ok=True)
    df_main = generate_student_dataset(n_samples=1500, random_state=42)
    df_main.to_csv('data/student_performance.csv', index=False)
    print(f"Generated data/student_performance.csv with {len(df_main)} records.")
    print("Performance category breakdown:")
    print(df_main['performance_category'].value_counts())
    print("\nSummary statistics:")
    print(df_main[['previous_marks', 'study_hours_per_day', 'attendance_percentage', 'assignment_completion_rate', 'final_marks']].describe())
    
    # Sample unseen data for batch test
    df_sample = generate_student_dataset(n_samples=25, random_state=999)
    df_sample['student_id'] = [f"NEW-{2000 + i}" for i in range(1, len(df_sample) + 1)]
    df_sample.to_csv('data/sample_student_data.csv', index=False)
    
    df_template = df_sample.drop(columns=['final_marks', 'performance_category'])
    df_template.to_csv('data/sample_input_template.csv', index=False)
    print("Sample test files generated successfully.")
