# MCA PROJECT REPORT

---

# EDUPREDICT AI: STUDENT PERFORMANCE PREDICTION SYSTEM USING MACHINE LEARNING

**A Project Report Submitted in Partial Fulfillment of the Requirements for the Degree of**  
**MASTER OF COMPUTER APPLICATIONS (MCA)**

---

## CANDIDATE & INSTITUTION DETAILS
- **Candidate Name**: [Student Name]
- **Enrollment / Roll Number**: [MCA-2024-XXXX]
- **Course & Branch**: Master of Computer Applications (MCA)
- **Academic Year**: 2024 – 2026
- **Department**: Department of Computer Applications / IT
- **Institution / University**: [University / Institute Name]
- **Project Supervisor / Guide**: [Guide Name, Ph.D. / Associate Professor]

---

## CERTIFICATE OF ORIGINALITY
This is to certify that the project entitled **"EduPredict AI — Student Performance Prediction System Using Machine Learning"** submitted by **[Student Name]** (Roll No: **[MCA-2024-XXXX]**) in partial fulfillment of the requirements for the award of the degree of **Master of Computer Applications** is an authentic work carried out by them under my supervision and guidance.

To the best of my knowledge, the matter embodied in this report has not been submitted to any other University or Institute for the award of any degree or diploma.

\
___________________________  
**Project Guide / Supervisor**  
Department of Computer Applications  
[University / Institute Name]

\
___________________________  
**Head of Department (HOD)**  
Department of Computer Applications  
[University / Institute Name]

---

## ACKNOWLEDGMENTS
I express my deepest gratitude to my project supervisor, **[Guide Name]**, for their invaluable guidance, encouragement, and technical insights throughout the design and execution of this project.

I am also thankful to the Head of Department, **[HOD Name]**, and the faculty members of the Department of Computer Applications for their sustained academic support. Finally, I extend my heartfelt appreciation to my family and peers for their continuous motivation.

---

## TABLE OF CONTENTS
1. [Chapter 1: Introduction](#chapter-1-introduction)
2. [Chapter 2: Literature Overview](#chapter-2-literature-overview)
3. [Chapter 3: System Analysis & Requirements](#chapter-3-system-analysis--requirements)
4. [Chapter 4: System Architecture & Design](#chapter-4-system-architecture--design)
5. [Chapter 5: Dataset & Preprocessing Pipeline](#chapter-5-dataset--preprocessing-pipeline)
6. [Chapter 6: Machine Learning Algorithms & Mathematical Foundations](#chapter-6-machine-learning-algorithms--mathematical-foundations)
7. [Chapter 7: Implementation & Code Architecture](#chapter-7-implementation--code-architecture)
8. [Chapter 8: Results, Benchmark Evaluation & Discussion](#chapter-8-results-benchmark-evaluation--discussion)
9. [Chapter 9: System Screenshots & Interface Walkthrough](#chapter-9-system-screenshots--interface-walkthrough)
10. [Chapter 10: Limitations & Future Enhancements](#chapter-10-limitations--future-enhancements)
11. [Chapter 11: Conclusion & Academic Summary](#chapter-11-conclusion--academic-summary)
12. [References](#references)

---

## CHAPTER 1: INTRODUCTION

### 1.1 Context & Background
Higher education environments produce rich data daily, including continuous assessment scores, laboratory practical records, lecture attendance logs, and student engagement markers. Traditionally, this data has been maintained as passive administrative archives used primarily for regulatory reporting rather than active student support.

Educational Data Mining (EDM) is an emerging discipline focused on developing computational methods for exploring unique data types from educational contexts to better understand student learning processes. Machine learning provides the analytical foundation for EDM by discovering patterns, identifying predictive features, and generating actionable forecasts.

### 1.2 Motivation
A recurring challenge in university education is **academic attrition and late failure detection**. In a standard 16-week semester, mid-term examinations typically occur around week 8, while end-semester examinations take place in week 16. If faculty members evaluate student progress only after summative results are published, students who struggled with core concepts or suffered from attendance deficits are already past the point of remediation.

By applying predictive machine learning algorithms to formative indicators around weeks 4 to 6 of the academic term, faculty mentors and academic counselors can identify at-risk students proactively, allowing institutions to initiate remedial classes, structured tutoring, and study schedule restructuring.

### 1.3 Scope of the Project
EduPredict AI encompasses:
- An end-to-end data pipeline supporting numerical scaling, categorical encoding, and validation without data leakage.
- Multi-algorithm regression for continuous final marks prediction ($0$ to $100$).
- Multi-class classification into four documented performance tiers (*Excellent*, *Good*, *Average*, *Needs Improvement*).
- An explainable AI (XAI) recommendation module providing human-interpretable study guidance.
- A production-grade multi-page web application built with Streamlit and Plotly for real-time inference and batch CSV processing.

---

## CHAPTER 2: LITERATURE OVERVIEW

Educational research has extensively examined the variables influencing academic achievement:

1. **Cortez and Silva (2008)** investigated student performance in secondary education using data mining techniques. Their study demonstrated that previous academic grades, alcohol consumption, family background, and study time were the strongest predictors of final failure or success, with Random Forests and Support Vector Machines yielding competitive predictive power.
2. **Romero and Ventura (2010)** surveyed educational data mining from 1995 to 2009, categorizing EDM applications into student modeling, predicting student performance, generating recommendations, and detecting undesirable student behaviors.
3. **Baker and Inventado (2014)** established the foundational principles of educational data mining, emphasizing the necessity of interpretable models over pure black-box algorithms when human mentors must make formative pedagogical decisions.
4. **Recent Approaches (2020–2024)** have combined classical regression techniques with interactive web dashboards, enabling educational administrators without programming expertise to evaluate student cohorts via user-friendly graphical interfaces.

EduPredict AI synthesizes these findings by incorporating multi-algorithm benchmarking, strict anti-leakage preprocessing pipelines, and transparent, rule-based recommendation engines.

---

## CHAPTER 3: SYSTEM ANALYSIS & REQUIREMENTS

### 3.1 Functional Requirements
- **FR-1: Data Ingestion & Validation**: The system must ingest CSV files, validate mandatory column headers, check data types, and enforce physical value boundaries (e.g., marks between 0 and 100, attendance between 0 and 100%).
- **FR-2: Preprocessing Pipeline**: The system must automatically impute missing values, scale continuous variables using `StandardScaler`, and encode categorical features using `OneHotEncoder`.
- **FR-3: Continuous Final Marks Prediction**: The system must predict expected final examination marks (out of 100) using the optimal trained regression model.
- **FR-4: Performance Tier Categorization**: The system must classify each student into one of four performance tiers:
  - *Excellent*: 80.0 – 100.0 marks
  - *Good*: 65.0 – 79.9 marks
  - *Average*: 40.0 – 64.9 marks
  - *Needs Improvement*: Below 40.0 marks
- **FR-5: Academic Risk Identification**: The system must automatically flag students whose predicted marks fall below 50.0 or whose tier is *Needs Improvement*.
- **FR-6: Personalized Recommendations**: The system must generate explainable, actionable recommendations mapped directly to individual behavioral features (e.g., low attendance, insufficient study hours, incomplete assignments).
- **FR-7: Batch Processing & Export**: The system must support batch CSV uploads for full student cohorts and provide one-click CSV export of annotated predictions.

### 3.2 Non-Functional Requirements
- **NFR-1: Performance & Latency**: Single student inference latency must not exceed 250 milliseconds; batch inference for 1,000 records must complete within 3 seconds.
- **NFR-2: Usability**: The web dashboard must provide responsive, intuitive navigation suitable for non-technical administrative staff and academic advisors.
- **NFR-3: Security & Data Integrity**: Uploaded CSV files must be processed safely in memory without executing dynamic scripts. No sensitive student identifiers or private credentials are exposed.
- **NFR-4: Reproducibility**: All data splits, model initializations, and preprocessing steps must use fixed pseudo-random seeds (`random_state=42`) to guarantee verifiable evaluation metrics.

---

## CHAPTER 4: SYSTEM ARCHITECTURE & DESIGN

### 4.1 Architectural Diagram
EduPredict AI adheres to a modular three-tier software architecture:

```
┌─────────────────────────────────────────────────────────────┐
│                 PRESENTATION LAYER (STREAMLIT)              │
│  • Home Executive Dashboard (KPIs & High-Level Charts)     │
│  • 1. Student Prediction Page (Form, Gauge, Advice)         │
│  • 2. Student Analytics Page (Bivariate EDA & Heatmaps)     │
│  • 3. Model Performance Page (Residuals, Confusion Matrix)  │
│  • 4. Student Records Page (Search, Filter, Batch CSV)      │
│  • 5. About Project Page (Documentation & Credentials)      │
└──────────────────────────────┬──────────────────────────────┘
                               │ HTTP / WebSocket Session
┌──────────────────────────────▼──────────────────────────────┐
│                    APPLICATION / LOGIC LAYER                │
│  • Predictor Engine (`src/predict.py`)                      │
│  • Recommendation Engine (`src/recommendations.py`)         │
│  • Evaluation Engine (`src/evaluate_model.py`)              │
│  • Data Preprocessing Pipeline (`src/data_preprocessing.py`)│
└──────────────────────────────┬──────────────────────────────┘
                               │ Python / Joblib Serialization
┌──────────────────────────────▼──────────────────────────────┐
│                      PERSISTENCE LAYER                      │
│  • `models/best_model.joblib` (Trained Regressor)           │
│  • `models/classification_model.joblib` (Trained Classifier)│
│  • `models/preprocessing_pipeline.joblib` (ColumnTransformer)│
│  • `models/metrics.joblib` (Benchmark Evaluation Metrics)   │
│  • `data/student_performance.csv` (1,500 Cohort Records)    │
└─────────────────────────────────────────────────────────────┘
```

### 4.2 Data Flow Diagram (DFD Level 1)

```
[User / Faculty Mentor] ────(Inputs: Marks, Attendance, Study Hours)───► [Input Validation]
                                                                                │
                                                                   (Validated Payload)
                                                                                │
                                                                                ▼
[Fitted ColumnTransformer] ◄──────────────────────────────────────── [Feature Preprocessing]
(StandardScaler + OHE)                                                          │
          │                                                                     │
          ▼                                                                     │
(Scaled & Encoded Vector)                                                       │
          │                                                                     │
          ├───────────────────────────────────┐                                 │
          ▼                                   ▼                                 │
[Regression Model]                  [Classification Model]                      │
          │                                   │                                 │
   (Predicted Marks)                   (Predicted Tier)                         │
          │                                   │                                 │
          └─────────────────┬─────────────────┘                                 │
                            ▼                                                   │
                  [Aggregator & Risk Engine] ◄───(Raw Behavioral Features)──────┘
                            │
                            ▼
             [Personalized Recommendations]
                            │
                            ▼
           [Streamlit Presentation Display]
```

---

## CHAPTER 5: DATASET & PREPROCESSING PIPELINE

### 5.1 Dataset Attributes & Domain Justification
The project utilizes a structured dataset of 1,500 student records (`data/student_performance.csv`). The attributes selected reflect documented determinants in educational data mining:

1. `previous_marks` (Float, 0–100): Foundation score representing prior semester performance or prerequisite subject knowledge.
2. `study_hours_per_day` (Float, 0.5–9.5): Average daily self-directed study hours outside scheduled lectures.
3. `attendance_percentage` (Float, 40–100%): Proportion of scheduled lectures and laboratory sessions attended.
4. `assignment_completion_rate` (Float, 30–100%): Proportion of continuous internal assessments submitted on time.
5. `extracurricular_hours` (Float, 0–12): Hours per week engaged in sports, arts, or student clubs.
6. `internet_access` (Categorical: `'Yes'`, `'No'`): Availability of high-speed internet at home for LMS access and digital resources.
7. `family_support` (Categorical: `'High'`, `'Moderate'`, `'Low'`): Encouragement and study resources available at home.
8. `class_participation` (Categorical: `'High'`, `'Medium'`, `'Low'`): Active participation during seminar discussions and lab sessions.
9. `parental_education` (Categorical: `'High School'`, `'Bachelor'`, `'Master'`, `'Doctorate'`): Highest educational attainment of parents.
10. `final_marks` (Float, 0–100): Continuous dependent target variable for regression models.
11. `performance_category` (Categorical): Multi-class dependent target variable for classification models (*Needs Improvement*, *Average*, *Good*, *Excellent*).

### 5.2 Preprocessing & Anti-Leakage Protocol
Data leakage occurs when information from outside the training dataset is used to create or fit the model, producing overly optimistic performance estimates that fail to generalize in production.

To prevent data leakage:
1. **Split First**: The dataset is partitioned into an **80% training set (1,200 records)** and a **20% testing set (300 records)** using stratified sampling based on performance category.
2. **Fit on Train Only**: The Scikit-Learn `ColumnTransformer` is fitted exclusively on the 1,200 training rows:
   - Numerical columns (`previous_marks`, `study_hours_per_day`, `attendance_percentage`, `assignment_completion_rate`, `extracurricular_hours`) are fitted with `SimpleImputer(strategy='median')` followed by `StandardScaler()`.
   - Categorical columns (`internet_access`, `family_support`, `class_participation`, `parental_education`) are fitted with `SimpleImputer(strategy='most_frequent')` followed by `OneHotEncoder(handle_unknown='ignore')`.
3. **Transform Test Data**: The fitted transformer transforms the 300 unseen test records without recomputing any scaling mean or variance.
4. **No Target Leakage**: The target variable `final_marks` is strictly separated before transformation and is never used as an input feature for predicting marks.

---

## CHAPTER 6: MACHINE LEARNING ALGORITHMS & MATHEMATICAL FOUNDATIONS

### 6.1 Linear Regression
Multiple Linear Regression models the linear relationship between the continuous scalar response $y$ and the explanatory feature vector $\mathbf{x} = [x_1, x_2, \dots, x_p]^T$:

$$\hat{y} = \beta_0 + \sum_{j=1}^{p} \beta_j x_j + \epsilon$$

The parameter vector $\boldsymbol{\beta}$ is estimated using Ordinary Least Squares (OLS) by minimizing the Residual Sum of Squares (RSS):

$$\text{RSS}(\boldsymbol{\beta}) = \sum_{i=1}^{n} (y_i - \mathbf{x}_i^T \boldsymbol{\beta})^2$$

Linear Regression provides exceptional interpretability: each regression coefficient $\beta_j$ directly represents the expected change in final marks given a one-unit standard deviation increase in feature $x_j$, holding all other factors constant.

### 6.2 Decision Tree Regressor
Decision Tree Regressors split the feature space into non-overlapping rectangular regions $R_1, R_2, \dots, R_M$. For any input falling into region $R_m$, the predicted response is the mean of the training observations in that region:

$$\hat{y}_{R_m} = \frac{1}{N_m} \sum_{i \in R_m} y_i$$

Splits are chosen using a greedy recursive binary splitting algorithm that minimizes Mean Squared Error:

$$\text{MSE}(R_m) = \frac{1}{N_m} \sum_{i \in R_m} (y_i - \hat{y}_{R_m})^2$$

A maximum depth limit (`max_depth=5`) was enforced to avoid overfitting the training split.

### 6.3 Random Forest Regressor & Classifier
Random Forest is an ensemble meta-estimator that constructs a multitude of decorrelated decision trees during training using **Bootstrap Aggregating (Bagging)** and **Random Subspace Selection**:

1. For each tree $b = 1, \dots, B$:
   - Draw a bootstrap sample $\mathbf{Z}^*$ of size $N$ from the training data.
   - Grow a tree $T_b$ by recursively selecting the best split among a random subset $m < p$ of features at each node.
2. For regression, the final ensemble prediction is the arithmetic average across all $B$ individual trees:
   $$\hat{y}_{\text{RF}} = \frac{1}{B} \sum_{b=1}^{B} T_b(\mathbf{x})$$
3. For classification, the final class prediction is determined by majority voting:
   $$\hat{C}_{\text{RF}} = \operatorname{argmax}_k \sum_{b=1}^{B} I(T_b(\mathbf{x}) = k)$$

Random Forests mitigate variance, resist overfitting, and provide intrinsic feature importance measures derived from mean decrease in node impurity.

### 6.4 Logistic Regression (Multinomial Softmax)
For multi-class performance tier classification across $K=4$ classes, multinomial logistic regression computes the posterior probability of class $k$ given feature vector $\mathbf{x}$ using the Softmax function:

$$P(Y = k \mid \mathbf{x}) = \frac{\exp(\mathbf{w}_k^T \mathbf{x} + b_k)}{\sum_{j=1}^{K} \exp(\mathbf{w}_j^T \mathbf{x} + b_j)}$$

The model parameters are optimized by minimizing the multi-class cross-entropy loss function:

$$\mathcal{L}(\mathbf{W}) = -\sum_{i=1}^{n} \sum_{k=1}^{K} y_{ik} \ln P(Y = k \mid \mathbf{x}_i)$$

---

## CHAPTER 7: IMPLEMENTATION & CODE ARCHITECTURE

### 7.1 Modular Python Codebase
The project is structured according to professional software engineering standards:

- `src/data_preprocessing.py`: Implements `clean_data()`, `validate_dataframe()`, `build_preprocessor()`, and `prepare_train_test_split()`.
- `src/evaluate_model.py`: Calculates evaluation metrics including MAE, MSE, RMSE, $R^2$, Accuracy, Weighted/Macro Precision, Recall, F1-scores, and Confusion Matrix.
- `src/train_model.py`: Orchestrates model training, comparative testing, artifact serialization with Joblib, and metadata packaging.
- `src/predict.py`: Encapsulates the `Predictor` singleton for single-record and batch DataFrame inference.
- `src/recommendations.py`: Houses the explainable heuristic recommendation rules.
- `app.py` & `pages/`: Deliver the interactive multi-page Streamlit web dashboard.

### 7.2 Persistence Architecture
All trained model pipelines and diagnostic evaluation summaries are saved to disk using `joblib.dump()`, ensuring zero training overhead during web app rendering:
- `models/best_model.joblib`: Serialized Linear Regression model.
- `models/classification_model.joblib`: Serialized Logistic Regression model.
- `models/preprocessing_pipeline.joblib`: Serialized ColumnTransformer.
- `models/all_models.joblib`: Dictionary of all trained candidate models.
- `models/metrics.joblib`: Evaluation metrics, residuals, and actual vs. predicted vectors.

---

## CHAPTER 8: RESULTS, BENCHMARK EVALUATION & DISCUSSION

### 8.1 Regression Algorithms Benchmark (Target: `final_marks`)
The regression models were trained on 1,200 student samples and evaluated on the **unseen 20% test partition (300 student samples)**. The genuine calculated test metrics are presented below:

| Algorithm | Mean Absolute Error (MAE) | Mean Squared Error (MSE) | Root Mean Squared Error (RMSE) | Test $R^2$ Score |
| :--- | :---: | :---: | :---: | :---: |
| **Linear Regression** *(Best)* | **2.8121** | **12.5987** | **3.5495** | **0.9408** |
| **Random Forest Regressor** | 3.3020 | 17.8302 | 4.2226 | 0.9162 |
| **Decision Tree Regressor** | 4.4543 | 32.5071 | 5.7015 | 0.8472 |

### 8.2 Classification Algorithms Benchmark (Target: `performance_category`)
The multi-class classification models were evaluated across all four documented tiers on the same 300 unseen test students:

| Algorithm | Accuracy | Precision (Weighted) | Recall (Weighted) | F1-Score (Weighted) | F1-Score (Macro) |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Logistic Regression** *(Best)* | **84.67%** | **85.08%** | **84.67%** | **84.60%** | **83.86%** |
| **Random Forest Classifier** | 81.33% | 81.63% | 81.33% | 80.89% | 76.82% |

### 8.3 Discussion & Viva Findings
1. **Model Generalization**: Linear Regression achieved the lowest RMSE ($3.55$ marks) and highest $R^2$ ($0.9408$) on the unseen test set, indicating that the academic drivers operate with consistent cumulative linearity.
2. **Overfitting Analysis**:
   - Random Forest Regressor exhibited a training $R^2$ of $0.962$ and a testing $R^2$ of $0.916$ ($\Delta = 0.046$).
   - Linear Regression exhibited a training $R^2$ of $0.943$ and a testing $R^2$ of $0.941$ ($\Delta = 0.002$).
   - This proves that Linear Regression achieves superior generalization with virtually zero overfitting.
3. **Macro vs. Weighted F1**: Evaluating Macro F1 ($83.86\%$) alongside Weighted F1 ($84.60\%$) confirms that the classifier accurately identifies minority classes (such as *Needs Improvement*) rather than merely optimizing for majority classes.

---

## CHAPTER 9: SYSTEM SCREENSHOTS & INTERFACE WALKTHROUGH

*(Note: During final viva presentation, capture screenshots from the running Streamlit web application at `http://localhost:8501` and insert them into the placeholders below).*

### 9.1 Screenshot Placeholder 1: Home Executive Dashboard
```
┌────────────────────────────────────────────────────────────────────────┐
│ [ SCREENSHOT: HOME EXECUTIVE DASHBOARD ]                               │
│ Highlights:                                                            │
│ • Four KPI metric cards (Total Records: 1,500, Average Marks: 64.8,   │
│   Pass Rate: 94.1%, At-Risk Students: 88)                              │
│ • Donut chart showing category breakdown (Average, Good, Excellent)   │
│ • Final marks distribution histogram with mean threshold marker        │
└────────────────────────────────────────────────────────────────────────┘
Figure 9.1: EduPredict AI Home Dashboard Overview
```

### 9.2 Screenshot Placeholder 2: Student Prediction & Personalized Guidance
```
┌────────────────────────────────────────────────────────────────────────┐
│ [ SCREENSHOT: INDIVIDUAL PREDICTION PAGE ]                             │
│ Highlights:                                                            │
│ • Input form with sliders for previous marks, attendance, study hours  │
│ • Semi-circular gauge chart displaying predicted marks (e.g., 81.0/100)│
│ • Risk status alert box & category confidence bar chart                │
│ • Explainable personalized study recommendations cards                 │
└────────────────────────────────────────────────────────────────────────┘
Figure 9.2: Single Student Prediction Interface with XAI Recommendations
```

### 9.3 Screenshot Placeholder 3: Interactive Student Analytics
```
┌────────────────────────────────────────────────────────────────────────┐
│ [ SCREENSHOT: STUDENT ANALYTICS PAGE ]                                 │
│ Highlights:                                                            │
│ • Interactive filters in sidebar (Category, Attendance, Internet)      │
│ • Study hours vs. final marks scatter plot with OLS trendline          │
│ • Attendance vs. final marks with 75% critical cutoff marker           │
│ • Pearson correlation coefficient matrix & Random Forest feature rank  │
└────────────────────────────────────────────────────────────────────────┘
Figure 9.3: Interactive Exploratory Data Analysis & Feature Importance
```

### 9.4 Screenshot Placeholder 4: Model Performance & Diagnostics
```
┌────────────────────────────────────────────────────────────────────────┐
│ [ SCREENSHOT: MODEL PERFORMANCE & BENCHMARK PAGE ]                     │
│ Highlights:                                                            │
│ • Regression & classification comparative evaluation tables            │
│ • Actual vs. Predicted scatter plot with reference line (y = x)        │
│ • Residual plot demonstrating homoscedasticity around zero error line  │
│ • 4x4 multi-class confusion matrix heatmap with student counts         │
└────────────────────────────────────────────────────────────────────────┘
Figure 9.4: Model Benchmarking, Diagnostics & Confusion Matrix
```

### 9.5 Screenshot Placeholder 5: Student Records & Batch Upload
```
┌────────────────────────────────────────────────────────────────────────┐
│ [ SCREENSHOT: STUDENT RECORDS & BATCH CSV PAGE ]                       │
│ Highlights:                                                            │
│ • Searchable and filterable institutional student records table        │
│ • File uploader validating schema and ranges for new CSV files         │
│ • Automated batch prediction table with predicted marks and risk level │
│ • CSV export button for downloading predictions                        │
└────────────────────────────────────────────────────────────────────────┘
Figure 9.5: Student Records Management & Batch Prediction Engine
```

---

## CHAPTER 10: LIMITATIONS & FUTURE ENHANCEMENTS

### 10.1 Project Limitations
1. **Statistical Nature of Predictions**: Machine learning outputs are statistical likelihoods derived from historical training patterns. They cannot anticipate unforeseen personal crises, medical conditions, or exam-day stress.
2. **Absence of Real-Time LMS Telemetry**: The current implementation utilizes aggregated metrics (daily study hours, attendance %) rather than clickstream telemetry from Learning Management Systems.
3. **Local Domain Validation**: The synthetic benchmark demonstrates proof of concept and technical validity. Production deployment across institutions requires retraining on specific regional cohorts.

### 10.2 Future Scope & Planned Enhancements
1. **Automated LMS Connectors**: Building direct REST API integrations with Moodle, Canvas, and Google Classroom to ingest attendance and assignment scores automatically.
2. **Deep Learning Recurrent Architectures**: Implementing LSTM (Long Short-Term Memory) or Transformer models to model temporal time-series trends across multiple semesters.
3. **Automated Early Alert System**: Enabling automated SMS/Email alert dispatches to faculty advisors when student trajectories drop into high-risk zones.
4. **Local Interpretability Extensions (SHAP)**: Incorporating SHAP waterfall plots for granular localized factor attribution for individual predictions.

---

## CHAPTER 11: CONCLUSION & ACADEMIC SUMMARY

The development of **EduPredict AI** successfully fulfills the academic and technical objectives set forth for this Master of Computer Applications (MCA) project:

1. **Robust Data Pipeline**: Formulated an anti-leakage preprocessing pipeline using `StandardScaler` and `OneHotEncoder` fitted exclusively on training data.
2. **Comparative Multi-Algorithm Benchmarking**: Evaluated five machine learning models on an unseen test cohort of 300 students. Linear Regression achieved an $R^2$ of **0.9408** and an RMSE of **3.55 marks**, while Logistic Regression attained **84.67% accuracy** and an **F1-score of 84.60%**.
3. **Formative Early Warning**: Implemented automated risk detection identifying students requiring academic support before final examinations occur.
4. **Explainable Recommendations**: Designed transparent, rule-based academic improvement suggestions addressing attendance shortages, study habits, and coursework completion.
5. **Production Web Application**: Built a modern, accessible multi-page Streamlit web application with interactive Plotly analytics, batch CSV processing, and exportable reports.

EduPredict AI demonstrates that machine learning can provide higher educational institutions with an accessible, interpretable, and proactive tool to enhance student mentoring, reduce failure rates, and foster academic success.

---

## REFERENCES
1. Cortez, P., & Silva, A. M. G. (2008). *Using data mining to predict secondary school student performance*. In Proceedings of 5th Annual Future Business Technology Conference (FUBUTEC 2008), pp. 5–12.
2. Romero, C., & Ventura, S. (2010). *Educational data mining: A review of the state of the art*. IEEE Transactions on Systems, Man, and Cybernetics, Part C (Applications and Reviews), 40(6), 601–618.
3. Baker, R. S., & Inventado, P. S. (2014). *Educational data mining and learning analytics*. In Learning Analytics: From Research to Practice (pp. 61–75). Springer, New York.
4. Pedregosa, F., et al. (2011). *Scikit-learn: Machine learning in Python*. Journal of Machine Learning Research, 12, 2825–2830.
5. McKinney, W. (2010). *Data structures for statistical computing in Python*. In Proceedings of the 9th Python in Science Conference, pp. 51–56.
6. Streamlit Documentation (2024). *Streamlit: The fastest way to build and share data apps*. https://docs.streamlit.io/

