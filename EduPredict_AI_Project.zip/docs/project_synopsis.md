# PROJECT SYNOPSIS

## 1. Title of the Project
**EduPredict AI — Student Performance Prediction System Using Machine Learning**

---

## 2. Degree & Academic Program
**Master of Computer Applications (MCA)**  
Department of Computer Applications / Information Technology

---

## 3. Abstract
Academic performance prediction is a pivotal research domain within **Educational Data Mining (EDM)** and **Learning Analytics**. In conventional educational frameworks, student evaluations are predominantly retrospective—struggling learners are detected only after mid-term or end-semester examinations, precluding timely pedagogical intervention. 

**EduPredict AI** proposes an automated, interpretable Machine Learning system that leverages continuous behavioral and academic indicators—such as daily study hours, lecture attendance percentage, assignment submission rate, classroom engagement, and prior examination scores—to forecast student end-semester examination marks and classify students into four standardized academic standing tiers (*Excellent*, *Good*, *Average*, *Needs Improvement*). 

The system implements multiple supervised learning algorithms: Linear Regression, Decision Tree Regressor, Random Forest Regressor, Logistic Regression, and Random Forest Classifier. Evaluated on an unseen 20% test partition, the optimal regression model achieves an $R^2$ score of **0.9408** with an RMSE of **3.55 marks**, while the multi-class classifier delivers **84.67% accuracy** and an **F1-score of 84.60%**. Integrated into a responsive Streamlit web application with interactive Plotly visual analytics and rule-based explainable recommendations, EduPredict AI provides institutions with a proactive early-warning system to support student retention and academic excellence.

---

## 4. Introduction
Higher education institutions routinely collect substantial volumes of academic and behavioral data. However, converting these administrative records into actionable pedagogical insights remains a challenge. Early forecasting of student achievement allows educators, academic counselors, and mentors to design personalized remedial pathways, organize tutorial sessions, and provide targeted counseling before summative assessments occur. EduPredict AI bridges the gap between raw educational data and formative mentoring through an accessible, interactive, and transparent data science workflow.

---

## 5. Problem Statement
Traditional academic tracking frameworks suffer from critical operational limitations:
1. **Retrospective Evaluation**: Academic evaluations are conducted post-facto. By the time final marks are released, remediation is impossible.
2. **Subjective Risk Assessment**: Faculty members often rely on intuition or isolated attendance rosters to assess risk, failing to recognize complex multivariate interactions.
3. **Lack of Explainability**: Generic prediction tools often act as "black boxes," providing numerical scores without explaining *why* a student is at risk or *what specific actions* can reverse the trend.
4. **Data Silos & Scalability Bottlenecks**: Batch evaluation across large student cohorts is manual, error-prone, and time-intensive.

---

## 6. Aim
To design, implement, and validate an end-to-end Machine Learning web application that predicts final examination scores, categorizes student performance tiers, detects at-risk learners early in the term, and generates explainable study improvement guidance.

---

## 7. Objectives
1. **Data Ingestion & Preprocessing Pipeline**: Formulate a robust data pipeline to clean records, handle missing values, validate schema boundaries, and apply `StandardScaler` and `OneHotEncoder` without data leakage.
2. **Multi-Model Training & Benchmarking**: Train and rigorously compare Linear Regression, Decision Trees, Random Forests, and Logistic Regression on unseen holdout test data.
3. **Early Academic Risk Detection**: Implement an alert mechanism that identifies students requiring academic support (predicted marks $< 50$ or tier *Needs Improvement*).
4. **Explainable AI (XAI) Recommendations**: Engineer a rule-based advisory engine that maps behavioral deficiencies to actionable, non-punitive study suggestions.
5. **Interactive Web Dashboard**: Build a responsive multi-page dashboard using Streamlit and Plotly for real-time individual prediction, cohort filtering, and batch CSV processing.

---

## 8. Existing System vs. Proposed System

| Dimension | Existing Conventional System | Proposed EduPredict AI System |
| :--- | :--- | :--- |
| **Intervention Timing** | Post-examination (reactive) | Mid-semester / Continuous (proactive) |
| **Risk Detection** | Manual inspection of attendance registers | Automated multivariate ML classification |
| **Prediction Granularity** | Qualitative teacher intuition | Precise quantitative marks (0–100) & grade tiers |
| **Actionable Feedback** | Generic feedback ("Work harder") | Personalized, explainable study recommendations |
| **Scalability** | Evaluated student-by-student | Automated batch CSV prediction for entire cohorts |
| **Data Analytics** | Static tabular rosters | Interactive dynamic Plotly dashboards & heatmaps |

---

## 9. Hardware & Software Requirements

### Hardware Requirements
- **Processor**: Intel Core i3 / AMD Ryzen 3 or higher (Intel Core i5 recommended)
- **RAM**: Minimum 4 GB (8 GB recommended for optimal multi-threaded training)
- **Storage**: Minimum 2 GB of available hard disk space
- **Display**: Minimum $1280 \times 720$ resolution screen

### Software Requirements
- **Operating System**: Windows 10 / Windows 11 (64-bit) or Linux/macOS
- **Programming Language**: Python 3.10.x to 3.11.x (CPython)
- **Web Application Framework**: Streamlit $\ge 1.30.0$
- **Machine Learning Library**: Scikit-Learn $\ge 1.3.0$
- **Data Analysis & Math**: Pandas $\ge 2.0.0$, NumPy $\ge 1.24.0$
- **Visualization Engines**: Plotly $\ge 5.18.0$, Matplotlib $\ge 3.8.0$, Seaborn $\ge 0.13.0$
- **Model Serialization**: Joblib $\ge 1.3.0$
- **IDE**: Visual Studio Code (VS Code) with Python & PowerShell extensions

---

## 10. Methodology

```
┌────────────────────────────────────────────────────────┐
│ Phase 1: Data Collection & Synthetic Simulation        │
│ • 1,500 records with realistic domain correlations    │
└───────────────────────────┬────────────────────────────┘
                            │
┌───────────────────────────▼────────────────────────────┐
│ Phase 2: Data Preprocessing & Validation               │
│ • Column validation, missing value imputation          │
│ • 80/20 Stratified Train-Test Split (random_state=42)  │
│ • Fitted StandardScaler & OneHotEncoder on Train only  │
└───────────────────────────┬────────────────────────────┘
                            │
┌───────────────────────────▼────────────────────────────┐
│ Phase 3: Model Training & Hyperparameter Tuning       │
│ • Linear Regression, Decision Tree, Random Forest      │
│ • Logistic Regression & Random Forest Classifier       │
└───────────────────────────┬────────────────────────────┘
                            │
┌───────────────────────────▼────────────────────────────┐
│ Phase 4: Model Evaluation on Unseen Test Cohort       │
│ • Regression: MAE, MSE, RMSE, R²                       │
│ • Classification: Accuracy, Precision, Recall, F1      │
└───────────────────────────┬────────────────────────────┘
                            │
┌───────────────────────────▼────────────────────────────┐
│ Phase 5: Artifact Persistence with Joblib              │
│ • Serialized best regressor, classifier & pipeline     │
└───────────────────────────┬────────────────────────────┘
                            │
┌───────────────────────────▼────────────────────────────┐
│ Phase 6: Streamlit Multi-Page Web Deployment           │
│ • Interactive Prediction, Analytics, Records & Docs    │
└────────────────────────────────────────────────────────┘
```

---

## 11. Expected Outcomes
1. High predictive accuracy for student final examination marks ($R^2 \ge 0.90$, RMSE $\le 4.5$ marks).
2. Robust multi-class classification into four academic categories with $F1 \ge 80\%$.
3. An intuitive, accessible web dashboard operable by non-technical faculty members.
4. Comprehensive batch upload capability enabling university administrators to evaluate entire student batches with single-click CSV export.

---

## 12. Applications
- **University & College Departments**: Early identification of students needing remedial classes.
- **Academic Mentorship Programs**: Providing data-informed conversation points for faculty advisors during one-on-one student meetings.
- **Student Self-Assessment Portals**: Enabling students to simulate the impact of increasing study hours or lecture attendance on projected grades.
- **Institutional Accreditation**: Supporting NAAC / NBA documentation for student performance tracking and continuous assessment.

---

## 13. Limitations
- **Statistical Estimation**: Predictions are statistical approximations and cannot account for sudden illness, family emergencies, or exam-day anxiety.
- **Synthetic Benchmark**: The primary demonstrative dataset simulates realistic domain correlations; production institutional deployment requires localized retraining.
- **Non-Clinical Scope**: Recommendations focus strictly on study habits and do not substitute for psychological counseling.

---

## 14. Future Scope
- **Direct LMS Integration**: Seamless API synchronization with Moodle, Canvas, and Blackboard.
- **Temporal Time-Series Modeling**: Incorporating recurrent architectures (LSTMs) to track weekly assignment trajectory over multi-semester horizons.
- **Automated Early Alert Dispatch**: Automated SMS/Email notifications to student advisors when a student falls below risk thresholds.
- **Local Interpretability via SHAP**: Integrating SHAP waterfall plots for granular localized factor explanations.

---

## 15. Conclusion
EduPredict AI establishes a reliable, interpretable, and practical Machine Learning system tailored to higher educational institutions. By combining rigorous preprocessing, multi-algorithm benchmarking, explainable advice, and an accessible Streamlit web application, the project delivers a comprehensive, college-ready MCA submission that addresses a critical challenge in educational technology.

