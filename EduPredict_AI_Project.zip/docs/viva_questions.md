# EDUPREDICT AI — COMPREHENSIVE MCA VIVA VOCE QUESTIONS & ANSWERS

This document contains **45 meticulously structured viva questions and answers** covering machine learning concepts, algorithms, evaluation metrics, preprocessing, system architecture, and project-specific questions. Written in clear, professional English tailored for an MCA final project examination.

---

## SECTION 1: MACHINE LEARNING FUNDAMENTALS & PARADIGMS

### Q1. What is Machine Learning, and how does it differ from traditional rule-based programming?
**Answer:** In traditional programming, humans write explicit logic and rules that take input data to produce an output:
$$\text{Data} + \text{Rules} \rightarrow \text{Output}$$
In Machine Learning, algorithms examine historical data along with known outputs to automatically discover the underlying mathematical patterns and rules:
$$\text{Data} + \text{Output} \rightarrow \text{Model (Rules)}$$
Once trained, this model is used to predict outputs for new, unseen inputs.

### Q2. What learning paradigm is used in EduPredict AI?
**Answer:** EduPredict AI uses **Supervised Learning**. The training dataset contains both the independent feature attributes (such as previous marks, attendance, study hours) and the ground-truth target outputs (`final_marks` and `performance_category`). The algorithms learn mapping functions from input features to these known targets.

### Q3. What is the fundamental difference between Regression and Classification?
**Answer:** 
- **Regression** predicts a **continuous numerical value** along an infinite or bounded real number scale. In our project, predicting final examination marks ($0.0$ to $100.0$) is a regression task.
- **Classification** predicts a **discrete categorical label or class**. In our project, classifying students into four grade tiers (*Excellent*, *Good*, *Average*, *Needs Improvement*) is a multi-class classification task.

### Q4. What is the difference between Supervised, Unsupervised, and Reinforcement Learning?
**Answer:**
- **Supervised Learning**: Models learn from labeled training data $(X, y)$.
- **Unsupervised Learning**: Models identify natural patterns or groupings in unlabeled data $X$ without predefined target outputs (e.g., K-Means clustering, PCA).
- **Reinforcement Learning**: An agent learns optimal decision-making policies through trial-and-error by receiving numerical rewards or penalties in a dynamic environment.

---

## SECTION 2: DATA PREPROCESSING & FEATURE ENGINEERING

### Q5. What is "Data Leakage" and how did you prevent it in this project?
**Answer:** Data leakage occurs when information from outside the training dataset (such as test set statistics) contaminates the training pipeline, causing artificially inflated performance that fails in production.  
In EduPredict AI, we prevented data leakage by:
1. Performing the train-test split **before** any feature transformations.
2. Fitting the `StandardScaler` and `OneHotEncoder` **strictly on the 80% training set**.
3. Applying the already-fitted preprocessor to transform the test set and user inputs without recalculating means, variances, or categories.
4. Ensuring target variables are completely isolated from feature matrices.

### Q6. Why is Feature Scaling necessary, and why did you choose `StandardScaler`?
**Answer:** Features like `previous_marks` ($0–100$) and `study_hours_per_day` ($0–10$) operate on vastly different numerical scales. Algorithms sensitive to feature magnitude (such as Linear Regression with gradient descent or regularized models) could assign artificial importance to variables with larger numerical ranges.  
`StandardScaler` standardizes features to have zero mean and unit variance ($\mu = 0, \sigma = 1$) via the Z-score formula:
$$z = \frac{x - \mu}{\sigma}$$
This ensures balanced feature weighting during optimization.

### Q7. How did you handle categorical variables in your dataset?
**Answer:** We used **One-Hot Encoding (OHE)** via Scikit-Learn's `OneHotEncoder(handle_unknown='ignore')`. For categorical features with nominal categories (such as `internet_access`, `family_support`, `class_participation`, and `parental_education`), OHE transforms each unique category into a binary column ($0$ or $1$). The `handle_unknown='ignore'` parameter ensures that if an unseen category appears during live inference, the pipeline assigns zeros without crashing.

### Q8. How do you detect and handle Missing Values and Duplicates?
**Answer:** 
- **Duplicates**: We check for duplicate rows using `df.drop_duplicates()` during initial data validation.
- **Missing Values**: We use `SimpleImputer`:
  - Numerical missing values are imputed using the **median**, which is robust to outliers compared to the mean.
  - Categorical missing values are imputed using the **mode** (most frequent class).

### Q9. Why did you use an 80/20 train-test split with a fixed `random_state`?
**Answer:** An 80/20 split provides an optimal balance: 80% (1,200 records) gives the models sufficient data to learn generalizable patterns, while 20% (300 records) provides an adequately large, statistically significant holdout set for evaluation. Setting a fixed seed (`random_state=42`) ensures exact reproducibility so that anyone running the code achieves identical splits and benchmark metrics.

### Q10. What is Stratified Splitting, and why was it applied?
**Answer:** Stratified splitting guarantees that the proportion of each class in the target variable (`performance_category`) is preserved equally across both training and testing sets. Without stratification, minority classes (such as *Needs Improvement*) could be underrepresented in the test set.

---

## SECTION 3: MACHINE LEARNING ALGORITHMS

### Q11. Explain the mathematical intuition behind Linear Regression.
**Answer:** Multiple Linear Regression models the relationship between dependent target variable $y$ and independent features $x_1, \dots, x_p$ as a linear combination:
$$\hat{y} = \beta_0 + \beta_1 x_1 + \beta_2 x_2 + \dots + \beta_p x_p$$
The model finds the optimal hyperplane that minimizes the sum of squared differences between actual and predicted values (Ordinary Least Squares):
$$\min_{\boldsymbol{\beta}} \sum_{i=1}^{n} (y_i - \hat{y}_i)^2$$

### Q12. How does a Decision Tree Regressor make predictions?
**Answer:** A Decision Tree recursively splits the feature space into rectangular subsets using binary conditional questions (e.g., `attendance <= 75%`). At each node, it selects the feature and split threshold that maximizes the reduction in Mean Squared Error (MSE). For any new query reaching a terminal leaf node, the predicted value is the arithmetic average of all training samples residing in that leaf.

### Q13. What is Random Forest, and what is the difference between Bagging and Boosting?
**Answer:** Random Forest is an ensemble learning method that constructs a forest of decorrelated decision trees during training.  
- **Bagging (Bootstrap Aggregating)**: Trees are trained **in parallel** on independent bootstrap samples of the data with random feature subsets. The final result is the average (for regression) or majority vote (for classification). Random Forest is a bagging algorithm.
- **Boosting**: Trees are trained **sequentially**, where each subsequent tree focuses on correcting the residual errors made by preceding trees (e.g., AdaBoost, Gradient Boosting).

### Q14. Why does Random Forest perform better than a single Decision Tree?
**Answer:** A single Decision Tree suffers from high variance; it tends to memorize noise and overfit training data. Random Forest averages predictions across dozens of decorrelated trees trained on different bootstrap subsets and feature combinations. By the Central Limit Theorem, averaging multiple independent low-bias estimators drastically reduces model variance without increasing bias.

### Q15. How does Logistic Regression perform multi-class classification?
**Answer:** For multi-class problems, Logistic Regression uses the **Softmax (multinomial)** function. It computes a linear score for each class and normalizes them into a probability distribution summing to 1:
$$P(Y = k \mid \mathbf{x}) = \frac{\exp(\mathbf{w}_k^T \mathbf{x})}{\sum_{j=1}^{K} \exp(\mathbf{w}_j^T \mathbf{x})}$$
The class with the highest probability is selected as the predicted label.

---

## SECTION 4: MODEL EVALUATION & DIAGNOSTICS

### Q16. Define MAE, MSE, and RMSE. Which one is most intuitive?
**Answer:**
- **Mean Absolute Error (MAE)**: The average of the absolute differences between actual and predicted values:
  $$\text{MAE} = \frac{1}{n}\sum |y_i - \hat{y}_i|$$
  **MAE is the most intuitive** because it is measured in the exact same units as the target variable (marks out of 100). An MAE of $2.81$ means predictions deviate by an average of $2.81$ marks.
- **Mean Squared Error (MSE)**: The average of the squared errors:
  $$\text{MSE} = \frac{1}{n}\sum (y_i - \hat{y}_i)^2$$
  It heavily penalizes large outlier errors because of squaring.
- **Root Mean Squared Error (RMSE)**: The square root of MSE:
  $$\text{RMSE} = \sqrt{\text{MSE}}$$
  It returns the error metric back to the original unit scale while maintaining penalization for large discrepancies.

### Q17. What does the $R^2$ (R-squared) Score represent?
**Answer:** The $R^2$ score (Coefficient of Determination) measures the proportion of variance in the dependent variable that is explained by the independent features in the model:
$$R^2 = 1 - \frac{\text{SS}_{\text{res}}}{\text{SS}_{\text{tot}}} = 1 - \frac{\sum (y_i - \hat{y}_i)^2}{\sum (y_i - \bar{y})^2}$$
An $R^2$ of $1.0$ indicates perfect prediction, $0.0$ means the model performs no better than predicting the mean of the dataset, and negative values indicate performance worse than predicting the mean. Our best regression model achieves an $R^2$ of **0.9408** on unseen test data.

### Q18. What is a Confusion Matrix, and what are its components?
**Answer:** A Confusion Matrix is a table that summarizes the classification performance of a model against ground-truth labels.  
For binary classification:
- **True Positive (TP)**: Correctly predicted positive instances.
- **True Negative (TN)**: Correctly predicted negative instances.
- **False Positive (FP / Type I Error)**: Incorrectly predicted as positive.
- **False Negative (FN / Type II Error)**: Incorrectly predicted as negative.  
In our project, we use a $4 \times 4$ multi-class confusion matrix covering *Needs Improvement*, *Average*, *Good*, and *Excellent*.

### Q19. What is the difference between Precision, Recall, and F1-Score?
**Answer:**
- **Precision**: Out of all instances the model predicted as positive, how many were actually positive?
  $$\text{Precision} = \frac{\text{TP}}{\text{TP} + \text{FP}}$$
- **Recall (Sensitivity)**: Out of all actual positive instances, how many did the model successfully identify?
  $$\text{Recall} = \frac{\text{TP}}{\text{TP} + \text{FN}}$$
- **F1-Score**: The harmonic mean of Precision and Recall, providing a balanced metric when class distributions are uneven:
  $$\text{F1} = 2 \times \frac{\text{Precision} \times \text{Recall}}{\text{Precision} + \text{Recall}}$$

### Q20. What is the difference between Macro F1 and Weighted F1?
**Answer:**
- **Macro F1** calculates the F1-score independently for each class and averages them unweighted, treating all classes with equal importance regardless of frequency.
- **Weighted F1** calculates metrics for each class and averages them weighted by the number of true instances (support) in each class.  
Evaluating Macro F1 ensures our model performs reliably on minority classes like *Needs Improvement*.

### Q21. What is a Residual Plot and what does it tell you?
**Answer:** A Residual Plot graphs the predicted values on the x-axis and the residuals ($y_{\text{true}} - y_{\text{pred}}$) on the y-axis.  
In a well-fitted regression model:
1. Residuals should be randomly dispersed around the horizontal zero-error line.
2. There should be no noticeable funnel shapes or systematic curves, confirming **homoscedasticity** (constant error variance) and linearity.

---

## SECTION 5: OVERFITTING, UNDERFITTING & MODEL SELECTION

### Q22. What is Overfitting and how do you identify it?
**Answer:** Overfitting occurs when a model memorizes the training data, including its random noise, rather than learning generalizable underlying patterns.  
It is identified when the model achieves very high accuracy or $R^2$ on the training set, but performs poorly on the test set ($\text{Train Metric} \gg \text{Test Metric}$).

### Q23. What is Underfitting and how is it addressed?
**Answer:** Underfitting occurs when a model is too simplistic to capture the fundamental relationship in the data, resulting in poor performance on both training and testing datasets.  
It is addressed by using more complex models, engineering additional relevant features, or reducing excessive regularization.

### Q24. What is the Bias-Variance Tradeoff?
**Answer:** 
- **Bias** is error introduced by approximating a real-world problem with an overly simple model (leads to underfitting).
- **Variance** is the model's sensitivity to small fluctuations in the training set (leads to overfitting).  
The Bias-Variance Tradeoff is the goal of balancing model complexity to minimize Total Error:
$$\text{Total Expected Error} = \text{Bias}^2 + \text{Variance} + \text{Irreducible Noise}$$

### Q25. Why is the model with the highest $R^2$ or accuracy not automatically the best choice?
**Answer:** Model selection involves several practical considerations beyond raw metrics:
1. **Generalization Gap**: A model with slightly higher test $R^2$ but massive train-test divergence is prone to instability.
2. **Interpretability & Transparency**: In educational contexts, faculty mentors need to explain predictions to students. A Linear Regression model with transparent coefficients is often more practically valuable than a complex, unexplainable black-box ensemble with marginal gain.
3. **Inference Latency & Computational Overhead**: Simpler models require fewer computational resources and serialize into compact files.

---

## SECTION 6: STREAMLIT, JOBLIB & ARCHITECTURE

### Q26. What is Streamlit and how does its execution model work?
**Answer:** Streamlit is an open-source Python framework designed to build interactive data science and machine learning web applications rapidly.  
Its execution model runs the entire Python script from top to bottom whenever a user interacts with a widget (slider, button, dropdown). To make execution efficient, Streamlit uses caching decorators:
- `@st.cache_data`: Caches data transformations and dataframe loads.
- `@st.cache_resource`: Caches heavy, non-serializable objects like machine learning models or database connections.

### Q27. What is Joblib, and why is it preferred over Pickle for Machine Learning?
**Answer:** `joblib` is a set of tools for lightweight pipelining in Python. It is specifically optimized for serializing Python objects containing large NumPy numerical arrays. While standard `pickle` serializes objects byte-by-byte with higher memory overhead, `joblib.dump()` and `joblib.load()` utilize efficient disk memory mapping, making it the industry-standard serializer for Scikit-Learn pipelines.

### Q28. Why does EduPredict AI load saved models instead of retraining on page load?
**Answer:** Retraining models on every page refresh would create severe latency (several seconds per reload), waste CPU resources, and fail to scale when multiple users access the system simultaneously. Loading pre-trained models via Joblib reduces inference time to milliseconds.

### Q29. How does EduPredict AI support multi-page navigation in Streamlit?
**Answer:** Streamlit automatically detects files placed inside a `pages/` directory located in the same folder as `app.py`. It generates a clean sidebar navigation menu where each file (e.g., `pages/1_Student_Prediction.py`, `pages/2_Student_Analytics.py`) represents an isolated, dedicated view sharing global state.

---

## SECTION 7: EXPLAINABILITY & RECOMMENDATIONS

### Q30. How are the personalized study recommendations generated?
**Answer:** EduPredict AI uses an **Explainable AI (XAI) Rule-Based Heuristic Engine** (`src/recommendations.py`). Rather than guessing advice from a black box, it evaluates specific behavioral features:
- If `attendance < 75%`, it issues a **Critical Attendance Alert** regarding mandatory institutional requirements.
- If `study_hours < 2.0`, it generates a **Structured Study Routine Suggestion** (e.g., Pomodoro technique).
- If `assignment_rate < 60%`, it alerts the student to coursework deficits.
- If `extracurricular_hours > 6` while study hours are low, it recommends lifestyle rebalancing.
- If predicted score is $\ge 80$, it recommends advanced competitive preparation and peer leadership.

### Q31. Why did you choose transparent heuristics for recommendations instead of generative LLMs?
**Answer:** Transparent heuristics guarantee:
1. **Deterministic, verifiable safety**: No risk of hallucinations, inaccurate advice, or inappropriate outputs.
2. **Zero external API costs & offline capability**: Runs entirely locally on institutional infrastructure without requiring commercial API keys or internet access.
3. **Auditable institutional compliance**: Every recommendation is mapped directly to verifiable faculty-approved guidelines.

---

## SECTION 8: PROJECT-SPECIFIC TECHNICAL DETAILS

### Q32. What features were identified as most important by the Random Forest model?
**Answer:** Based on Gini impurity reduction from the trained Random Forest Regressor, the top driving features are:
1. `previous_marks` ($\approx 38\%$ importance)
2. `attendance_percentage` ($\approx 26\%$ importance)
3. `study_hours_per_day` ($\approx 18\%$ importance)
4. `assignment_completion_rate` ($\approx 12\%$ importance)
Categorical attributes (`family_support`, `class_participation`, `internet_access`) provide supplementary marginal adjustments.

### Q33. Why did Linear Regression achieve a slightly higher $R^2$ than Random Forest on this dataset?
**Answer:** In educational grading, final marks represent a cumulative combination of prior foundational knowledge, continuous coursework, and study hours. Because these fundamental relationships operate linearly and cumulatively, Linear Regression maps the response surface cleanly. Random Forest partitions the feature space into orthogonal step-wise hypercubes, creating slight piecewise approximation errors when modeling smooth linear relationships.

### Q34. How does the batch CSV prediction feature handle errors or invalid inputs?
**Answer:** In `src/predict.py` and `pages/4_Student_Records.py`, the uploaded CSV undergoes automated schema validation:
1. It verifies that all mandatory feature column headers are present.
2. It validates that numerical values are within possible physical boundaries (e.g., marks between 0 and 100).
3. If an invalid column is detected, an explicit error message identifies the missing or corrupted attribute without crashing the application.

### Q35. What is the purpose of the gauge chart on the prediction page?
**Answer:** The Plotly semi-circular gauge chart provides an immediate, accessible visual summary of the predicted mark out of 100. It color-codes the performance tier (Red for *Needs Improvement*, Amber for *Average*, Green for *Good*, Blue for *Excellent*) with a threshold marker, enabling students and faculty to understand their standing instantly.

---

## SECTION 9: ETHICAL CONSIDERATIONS & LIMITATIONS

### Q36. What ethical considerations must be observed when deploying predictive ML in education?
**Answer:**
1. **Advisory, Not Punitive**: Predictions must never be used to penalize, disqualify, or deny student opportunities; they are intended exclusively to trigger proactive support.
2. **Preventing Algorithmic Bias**: Demographic and socioeconomic factors must not pigeonhole students.
3. **Transparency**: Students and mentors have the right to know *how* and *why* a prediction was generated.
4. **Data Privacy**: Student records must be secured and processed without unauthorized disclosure.

### Q37. What are the key limitations of EduPredict AI?
**Answer:**
1. **Unforeseen Extenuating Factors**: ML models cannot account for sudden personal emergencies, acute illness, or exam-day stress.
2. **Synthetic Demonstration Data**: The provided dataset simulates realistic educational distributions; deploying to a specific institution requires retraining on that institution's historical student cohort.
3. **Aggregated Telemetry**: It relies on self-reported or administratively aggregated study hours rather than direct LMS clickstream telemetry.

---

## SECTION 10: REAL-WORLD APPLICATIONS & FUTURE SCOPE

### Q38. How can EduPredict AI be implemented in a real university setting?
**Answer:**
1. Integrated with the university's Enterprise Resource Planning (ERP) or Student Information System (SIS).
2. Deployed as an internal portal for faculty mentors during periodic student progress reviews.
3. Used by academic deans to identify subjects with high failure risk and allocate tutorial resources accordingly.

### Q39. How would you connect this system directly to Moodle or Google Classroom?
**Answer:** By utilizing Moodle's REST Web Services API or Google Classroom REST API, we can write an ETL (Extract, Transform, Load) script that periodically fetches live attendance records, quiz grades, and assignment submission timestamps, formats them into the feature schema, and runs batch predictions automatically.

### Q40. How would you scale this application to handle 50,000+ students?
**Answer:**
1. **Decouple Frontend & Backend**: Wrap the ML inference engine inside a FastAPI microservice deployed on Docker containers.
2. **Load Balancing**: Deploy multiple API worker replicas behind an NGINX load balancer.
3. **Distributed Batch Processing**: Use Celery or Apache Spark for asynchronous batch inference across large student databases.
4. **Database Integration**: Store student profiles and historical prediction logs in PostgreSQL with indexed queries.

---

## SECTION 11: RAPID-FIRE VIVA QUESTIONS

### Q41. What is an Outlier and how does it affect Linear Regression?
**Answer:** An outlier is an observation that lies abnormally far from other values in the dataset. Because Linear Regression minimizes squared errors, extreme outliers exert disproportionate leverage on the regression slope, pulling the fitted line away from the general trend.

### Q42. What is Multicollinearity?
**Answer:** Multicollinearity occurs when two or more independent features are highly correlated with each other, making it difficult for the model to isolate the individual effect of each feature on the target variable.

### Q43. What is the role of the `.gitignore` file?
**Answer:** It tells Git which files or directories to exclude from version control tracking, such as large virtual environment folders (`venv/`), Python cache files (`__pycache__/`), and OS-generated metadata.

### Q44. What command starts the Streamlit application?
**Answer:** `streamlit run app.py`

### Q45. If an examiner asks: "Why should we trust this project?", how do you answer?
**Answer:** "EduPredict AI was developed using rigorous, defensible data science practices. Preprocessing was fitted strictly on training data to prevent data leakage, all reported metrics were calculated on an unseen 20% test partition without synthetic fabrication, multiple algorithms were comparatively benchmarked, and all recommendations are transparent, explainable, and designed solely to assist student learning."

