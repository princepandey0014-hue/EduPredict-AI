# EDUPREDICT AI — TECHNICAL WORKFLOW & PIPELINE DOCUMENTATION

This document details the step-by-step engineering workflow of **EduPredict AI**, detailing how data moves through preprocessing, training, model evaluation, artifact serialization, and live Streamlit deployment.

---

## 1. HIGH-LEVEL ARCHITECTURAL WORKFLOW

```
┌────────────────────────────────────────────────────────────────────────┐
│                        DATA INGESTION & STORAGE                       │
│  • data/student_performance.csv (1,500 cohort records, 12 attributes)  │
│  • data/sample_student_data.csv (Holdout evaluation samples)           │
│  • data/sample_input_template.csv (Blank batch inference template)     │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
┌───────────────────────────────────▼────────────────────────────────────┐
│                  DATA CLEANING & RANGE VALIDATION                      │
│  • Remove duplicates via drop_duplicates()                             │
│  • Impute missing numerical values with median                         │
│  • Impute missing categorical values with mode                         │
│  • Verify value bounds: marks [0,100], attendance [0,100]              │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
┌───────────────────────────────────▼────────────────────────────────────┐
│              STRATIFIED TRAIN-TEST PARTITIONING                        │
│  • 80% Training Set (1,200 records)                                    │
│  • 20% Holdout Test Set (300 records)                                  │
│  • Stratified by 'performance_category' (random_state=42)              │
│  • Target variables completely isolated (zero data leakage)            │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
┌───────────────────────────────────▼────────────────────────────────────┐
│                  PREPROCESSING PIPELINE FITTING                        │
│  • Fitted strictly on the 1,200 training samples only:                 │
│    - Numerical features -> StandardScaler() (zero mean, unit var)      │
│    - Categorical features -> OneHotEncoder(handle_unknown='ignore')    │
│  • Transform 300 test samples using already-fitted parameters          │
│  • Resulting feature space: 17 engineered features                     │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
┌───────────────────────────────────▼────────────────────────────────────┐
│              MULTI-ALGORITHM MODEL TRAINING PIPELINE                   │
│  • Regression Models (Predicting 'final_marks'):                       │
│    1. Linear Regression (OLS)                                          │
│    2. Decision Tree Regressor (max_depth=5)                            │
│    3. Random Forest Regressor (n_estimators=120, max_depth=8)          │
│  • Classification Models (Predicting 'performance_category'):          │
│    1. Multinomial Logistic Regression (max_iter=1000)                  │
│    2. Random Forest Classifier (n_estimators=120, max_depth=8)         │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
┌───────────────────────────────────▼────────────────────────────────────┐
│              UNSEEN TEST EVALUATION & BENCHMARKING                     │
│  • Regression: Calculate MAE, MSE, RMSE, R²                            │
│  • Classification: Calculate Accuracy, Precision, Recall, F1           │
│  • Multi-Class Confusion Matrix generation                             │
│  • Residual calculation & Homoscedasticity verification                │
│  • Random Forest Feature Importance extraction                         │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
┌───────────────────────────────────▼────────────────────────────────────┐
│                   ARTIFACT SERIALIZATION (JOBLIB)                      │
│  • models/best_model.joblib (Optimal Regressor)                        │
│  • models/classification_model.joblib (Optimal Classifier)             │
│  • models/preprocessing_pipeline.joblib (Fitted ColumnTransformer)     │
│  • models/all_models.joblib (Candidate model dictionary)               │
│  • models/metrics.joblib (Benchmark metrics & diagnostic arrays)       │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
┌───────────────────────────────────▼────────────────────────────────────┐
│               STREAMLIT PRODUCTION WEB APPLICATION                     │
│  • app.py: Executive Dashboard (KPI metric cards & distribution)       │
│  • pages/1_Student_Prediction.py: Individual form, gauge, advice       │
│  • pages/2_Student_Analytics.py: Interactive Plotly EDA charts         │
│  • pages/3_Model_Performance.py: Benchmarks, residuals & matrix        │
│  • pages/4_Student_Records.py: Search, filter & batch CSV inference    │
│  • pages/5_About_Project.py: Synopsis, workflow & student credentials  │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 2. DETAILED PIPELINE STAGES

### Stage 1: Feature Ingestion & Range Validation
The dataset contains nine predictive attributes:
- **Numerical Features**: `previous_marks`, `study_hours_per_day`, `attendance_percentage`, `assignment_completion_rate`, `extracurricular_hours`.
- **Categorical Features**: `internet_access`, `family_support`, `class_participation`, `parental_education`.

Before passing data into the transformation pipeline, `validate_dataframe()` checks:
1. All required column names are present in the dataframe.
2. Numerical values reside within physically realistic bounds.
3. Categorical values contain valid categories.

### Stage 2: Anti-Leakage Preprocessing Protocol
To prevent data leakage, the transformation pipeline is defined using Scikit-Learn's `ColumnTransformer`:
```python
numeric_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='median')),
    ('scaler', StandardScaler())
])

categorical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='most_frequent')),
    ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
])

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numeric_transformer, NUMERICAL_FEATURES),
        ('cat', categorical_transformer, CATEGORICAL_FEATURES)
    ]
)
```
- **Crucial Rule**: `preprocessor.fit_transform(X_train)` is executed on the training split only.
- Test data and real-time user inputs use `preprocessor.transform(X_test)` so that no test statistics leak into the scaler.

### Stage 3: Multi-Algorithm Training & Evaluation
The training pipeline iterates through each algorithm:
1. **Fit**: The model fits on `X_train_proc` against target labels.
2. **Predict**: The model generates predictions on `X_test_proc`.
3. **Evaluate**: Real metrics are calculated using `src/evaluate_model.py`.
4. **Select Best**:
   - Optimal Regressor is selected based on highest test $R^2$ (and lowest RMSE).
   - Optimal Classifier is selected based on highest weighted test F1-score.

### Stage 4: Artifact Persistence
The fitted objects are serialized to disk using `joblib.dump()`. This enables the web application to load pre-trained pipelines in sub-second time without retraining on each page reload.

---

## 3. RETRAINING PROTOCOL FOR NEW INSTITUTIONAL DATASETS

When an educational institution collects new semester data, administrators can retrain the models with a single command:

1. Replace or update the file `data/student_performance.csv` with the new cohort records. Ensure that column names match the required schema.
2. Open PowerShell in the project directory.
3. Activate the virtual environment:
   ```powershell
   .\venv\Scripts\Activate.ps1
   ```
4. Run the automated training script:
   ```powershell
   python -m src.train_model
   ```
5. The pipeline automatically validates the new dataset, fits new transformers, retrains all algorithms, calculates new metrics, and overwrites the `.joblib` files.
6. Refresh the Streamlit browser window to immediately utilize the updated models.

---

## 4. INFERENCE WORKFLOW (SINGLE & BATCH)

### Single Student Inference
1. Faculty advisor enters student parameters via Streamlit widgets.
2. Inputs are packaged into a Python dictionary.
3. `Predictor.predict_single()` passes the dictionary through `preprocessor.transform()`.
4. The regression model predicts final marks (bounded between $0$ and $100$).
5. The classification model predicts the performance tier.
6. The recommendation engine evaluates behavioral triggers and returns actionable guidance.
7. Streamlit renders the Plotly gauge, confidence breakdown, and recommendations.

### Batch CSV Inference
1. User uploads a CSV file via `st.file_uploader()`.
2. Schema validation confirms required feature columns.
3. `Predictor.predict_batch()` runs vectorized inference across all rows.
4. Three new columns are appended: `predicted_marks`, `predicted_category`, and `academic_risk`.
5. Streamlit renders an interactive preview and a one-click **Download CSV** button.

