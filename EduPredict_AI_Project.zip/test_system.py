"""
End-to-End System Integration Test for EduPredict AI.
Verifies all modules, data loading, model inference, recommendations,
batch predictions, and page syntax compilations.
"""

import os
import sys
import py_compile
import pandas as pd

# Ensure standard UTF-8 console output on Windows
if sys.stdout.encoding != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

def run_integration_tests():
    print("=" * 65)
    print("   Running EduPredict AI Integration Test Suite")
    print("=" * 65)
    
    # 1. Test Syntax of all Python files
    py_files = [
        'app.py',
        'src/__init__.py',
        'src/data_preprocessing.py',
        'src/evaluate_model.py',
        'src/train_model.py',
        'src/predict.py',
        'src/recommendations.py',
        'pages/1_Student_Prediction.py',
        'pages/2_Student_Analytics.py',
        'pages/3_Model_Performance.py',
        'pages/4_Student_Records.py',
        'pages/5_About_Project.py'
    ]
    
    print("\n[Test 1/5] Compiling and validating Python source syntax...")
    for f in py_files:
        try:
            py_compile.compile(f, doraise=True)
            print(f"  ✓ Syntax valid: {f}")
        except Exception as e:
            print(f"  ✗ Syntax Error in {f}: {e}")
            return False
            
    # 2. Test Data Preprocessing
    print("\n[Test 2/5] Testing Data Preprocessing Pipeline...")
    from src.data_preprocessing import load_data, validate_dataframe, clean_data, build_preprocessor, prepare_train_test_split
    df = load_data('data/student_performance.csv')
    is_valid, msg = validate_dataframe(df)
    assert is_valid, f"Validation failed: {msg}"
    assert len(df) == 1500, f"Expected 1500 rows, found {len(df)}"
    print(f"  ✓ Data integrity passed: 1,500 records verified.")
    
    # 3. Test Inference Engine on Single Student
    print("\n[Test 3/5] Testing Single Student Inference...")
    from src.predict import get_predictor
    predictor = get_predictor()
    
    sample_student = {
        'previous_marks': 85.0,
        'study_hours_per_day': 5.0,
        'attendance_percentage': 92.0,
        'assignment_completion_rate': 95.0,
        'extracurricular_hours': 2.0,
        'internet_access': 'Yes',
        'family_support': 'High',
        'class_participation': 'High',
        'parental_education': 'Master'
    }
    
    res = predictor.predict_single(sample_student)
    assert 'predicted_marks' in res
    assert 'predicted_category' in res
    assert 'recommendations' in res
    print(f"  ✓ Predicted Marks: {res['predicted_marks']}/100")
    print(f"  ✓ Predicted Category: {res['predicted_category']}")
    print(f"  ✓ Risk Evaluation: {res['risk_level']}")
    print(f"  ✓ Recommendations generated: {len(res['recommendations'])}")
    
    # 4. Test Batch Prediction on CSV
    print("\n[Test 4/5] Testing Batch CSV Prediction...")
    sample_df = pd.read_csv('data/sample_student_data.csv')
    batch_res = predictor.predict_batch(sample_df)
    assert 'predicted_marks' in batch_res.columns
    assert 'predicted_category' in batch_res.columns
    assert 'academic_risk' in batch_res.columns
    assert len(batch_res) == len(sample_df)
    print(f"  ✓ Successfully processed batch of {len(batch_res)} records.")
    print(f"  ✓ Sample batch predicted marks mean: {batch_res['predicted_marks'].mean():.2f}")
    
    # 5. Test Models & Metrics persistence
    print("\n[Test 5/5] Verifying Serialized Artifacts...")
    required_models = [
        'models/best_model.joblib',
        'models/classification_model.joblib',
        'models/preprocessing_pipeline.joblib',
        'models/all_models.joblib',
        'models/metrics.joblib'
    ]
    for m in required_models:
        assert os.path.exists(m), f"Missing model artifact: {m}"
        print(f"  ✓ Artifact verified on disk: {m}")
        
    print("\n" + "=" * 65)
    print("   ALL INTEGRATION TESTS PASSED PERFECTLY! (100% SUCCESS)")
    print("=" * 65)
    return True

if __name__ == '__main__':
    success = run_integration_tests()
    if not success:
        sys.exit(1)
