"""
Create clean, portable ZIP archive of EduPredict AI project.
Excludes virtual environments, cache files, and logs.
"""

import os
import zipfile

def create_project_zip(output_filename="EduPredict_AI_Project.zip"):
    base_dir = os.path.dirname(os.path.abspath(__file__))
    zip_path = os.path.join(base_dir, output_filename)
    
    exclude_dirs = {'venv', '.venv', '__pycache__', '.git', '.pytest_cache', '.vscode', 'scratch', '.system_generated'}
    exclude_extensions = {'.pyc', '.pyo', '.pyd', '.zip', '.log'}
    
    print(f"Creating project archive: {output_filename}...")
    file_count = 0
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(base_dir):
            # Prune excluded directories in-place
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            
            for file in files:
                _, ext = os.path.splitext(file)
                if ext in exclude_extensions or file == output_filename:
                    continue
                
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, base_dir)
                zipf.write(full_path, rel_path)
                file_count += 1
                
    zip_size_mb = os.path.getsize(zip_path) / (1024 * 1024)
    print(f"Archive successfully created: {zip_path}")
    print(f"Total files archived: {file_count} | Archive size: {zip_size_mb:.2f} MB")
    return zip_path

if __name__ == '__main__':
    create_project_zip()

